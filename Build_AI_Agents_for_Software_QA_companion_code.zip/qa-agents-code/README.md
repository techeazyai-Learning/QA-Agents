# Companion code: Build AI Agents for Software QA

The complete code pack for the book: a shared toolbox, 21 agents
(Chapters 4 to 24), an orchestrator, a red-team exercise, measurement
functions and an agent scaffold (Chapters 25 to 28).

## Run it offline (no account needed)

    python -m venv .venv && source .venv/bin/activate
    pip install pytest pillow
    python -m pytest -q          # 256 tests, all chapters
    python hello_qa.py           # stand-in model, no network
    python run_eval.py           # score the stand-in on golden/
    python run_part2.py ch5      # Part II demos: ch5 to ch9
    python run_part3.py ch10     # Part III: ch10 to ch15 (Pillow for ch15)
    python run_part4.py ch16     # Part IV: ch16 to ch19
    python run_part5.py ch20     # Part V: ch20 to ch22
    python run_part6.py ch23     # Part VI: ch23, ch24 (--audience)
    python run_part7.py ch25     # Part VII: ch25 to ch28

## Run it against a real model

    pip install anthropic        # or: pip install openai
    export ANTHROPIC_API_KEY=... # or OPENAI_API_KEY=...
    export QA_AGENT_MODEL=<model name from your provider's docs>
    python hello_qa.py --provider anthropic
    python run_eval.py --provider anthropic

Model names are never hard-coded because they change. The stand-in
models in `qa_agents/fake_model.py` and `qa_agents/fakes.py` are rule-based and is NOT an AI: it
only lets the plumbing be tested offline. Its scores say nothing about
a real model.

Tested on Python 3.13. The syntax is kept compatible with 3.10+.
Keep secrets out of version control: add `.env`, `.venv/` and `runs/`
to `.gitignore`. All sample data is invented.

## Capturing your own pages (Chapters 13 to 15, optional)

The golden data for the browser-based agents was produced once by the
Node scripts in `capture/`. You only need them for your own pages.

    npm install playwright axe-core
    npx playwright install chromium
    node capture/capture_a11y.js
    node capture/capture_payload.js
    node capture/capture_visual.js

Versions used: Playwright 1.56.0, axe-core 4.14.0.

## Notes

- Python 3.13 is the only version the tests were run on. Older
  versions (3.10 and later) are the target but untested.
- The review log and time study in `golden/` are INVENTED (see
  `golden/make_review_log.py`). Replace them with your own records.
- `python -m qa_agents.new_agent SPEC.json` generates a new agent
  module and test file; it never overwrites existing files.
