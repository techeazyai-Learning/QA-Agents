// Runs axe-core on a page and saves the raw violations.
// Needs: npm install axe-core playwright
// Usage: node capture/capture_a11y.js
const { chromium } = require("playwright");
const fs = require("fs");
const path = require("path");

const axePath = require.resolve("axe-core/axe.min.js");
const axeSource = fs.readFileSync(axePath, "utf8");
const root = path.resolve(__dirname, "..");
const target = path.join(root, "fixtures", "refund_a11y_bad.html");

(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage();
  await page.goto("file://" + target);
  await page.evaluate(axeSource);
  const results = await page.evaluate(() => axe.run());
  const saved = {
    axeVersion: results.testEngine.version,
    url: "refund_a11y_bad.html",
    violations: results.violations,
  };
  fs.writeFileSync(path.join(root, "golden", "axe_results.json"),
    JSON.stringify(saved, null, 1));
  console.log(saved.axeVersion, saved.violations.length);
  await browser.close();
})();
