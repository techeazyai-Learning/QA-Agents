// Captures an API response and the text the page shows for it.
// Usage: node capture/capture_payload.js
const { chromium } = require("playwright");
const fs = require("fs");
const path = require("path");

const root = path.resolve(__dirname, "..");
const API = "https://shop.example.test/api/orders/ORD-1042";
const payload = {
  id: "ORD-1042", status: "partially_refunded", total: 1249.5,
  refunded: 20, refundable: 1229.5, currency: "USD",
  delivered_on: "2026-10-24",
  customer: { name: "Asha Ardent", email: "asha.ardent@example.test" },
  refunds: [{ id: "RF-1", amount: 20 }],
  internal_risk_score: 0.12,
};

(async () => {
  const browser = await chromium.launch();
  // A fixed time zone keeps the run repeatable on any machine.
  const context = await browser.newContext({
    timezoneId: "America/Los_Angeles",
  });
  const page = await context.newPage();
  await page.route(API, (route) => route.fulfill({
    status: 200, contentType: "application/json",
    headers: { "access-control-allow-origin": "*" },
    body: JSON.stringify(payload),
  }));
  const waiting = page.waitForResponse(API);
  const view = path.join(root, "fixtures", "order_view.html");
  await page.goto("file://" + view);
  const apiBody = await (await waiting).json();
  await page.locator("dd").first().waitFor();
  const ui = await page.evaluate(() => {
    const out = {};
    document.querySelectorAll("dt").forEach((dt) => {
      out[dt.innerText.trim()] = dt.nextElementSibling.innerText.trim();
    });
    return out;
  });
  const dir = path.join(root, "golden");
  fs.writeFileSync(path.join(dir, "order_api.json"),
    JSON.stringify(apiBody, null, 1));
  fs.writeFileSync(path.join(dir, "order_ui.json"),
    JSON.stringify(ui, null, 1));
  await browser.close();
})();
