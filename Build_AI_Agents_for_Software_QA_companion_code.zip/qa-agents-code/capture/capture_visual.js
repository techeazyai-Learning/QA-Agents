// Screenshots and element boxes for two versions of a page.
// Usage: node capture/capture_visual.js
const { chromium } = require("playwright");
const fs = require("fs");
const path = require("path");

const root = path.resolve(__dirname, "..");
const out = path.join(root, "golden", "visual");
fs.mkdirSync(out, { recursive: true });
const SELECTORS = "h1, #order, label, input, select, button, .note";

async function shot(browser, name, file) {
  const page = await browser.newPage({
    viewport: { width: 760, height: 460 },
  });
  await page.goto("file://" + path.join(root, "fixtures", file));
  await page.screenshot({ path: path.join(out, name + ".png") });
  const boxes = await page.evaluate((sel) =>
    [...document.querySelectorAll(sel)].map((el) => {
      const r = el.getBoundingClientRect();
      const cls = el.className ? "." + el.className : "";
      return {
        selector: el.id ? "#" + el.id : el.tagName.toLowerCase() + cls,
        text: (el.innerText || el.value || "").trim().slice(0, 40),
        x: Math.round(r.x), y: Math.round(r.y),
        w: Math.round(r.width), h: Math.round(r.height),
      };
    }), SELECTORS);
  fs.writeFileSync(path.join(out, name + "_boxes.json"),
    JSON.stringify(boxes, null, 1));
  await page.close();
}

(async () => {
  const browser = await chromium.launch();
  await shot(browser, "baseline", "refund_v1.html");
  await shot(browser, "current", "refund_v2.html");
  await browser.close();
})();
