"""Writes golden/test_runs.json: INVENTED CI history for Chapter 19.

40 runs over 10 commits (4 runs each), three runners. Nothing here
comes from a real pipeline. Run it to recreate the file.
"""
import json
from pathlib import Path

TESTS = ["test_login", "test_refund_email_sent",
         "test_refund_service_happy", "test_refund_amount_limits",
         "test_search_orders", "test_audit_log_written"]
RUNNERS = ["ci-1", "ci-2", "ci-3"]
records = []
for run in range(40):
    commit = f"c{run // 4 + 1}"
    runner = RUNNERS[run % 3]
    order = list(TESTS)
    if run % 5 == 0:            # some runs reorder the suite
        order = ["test_audit_log_written", "test_refund_service_happy"]\
            + [t for t in TESTS if t not in
               ("test_audit_log_written", "test_refund_service_happy")]
    prev = None
    for test in order:
        outcome, error, ms = "pass", "", 120
        if test == "test_refund_email_sent" and runner == "ci-3" \
                and run % 2 == 0:
            outcome = "fail"
            error = ("TimeoutError: waiting for mailbox message "
                     "(5000 ms)")
            ms = 5000
        if test == "test_refund_service_happy" \
                and prev == "test_audit_log_written" \
                and run % 10 in (0, 5):
            outcome = "fail"
            error = "AssertionError: expected 1 refund, found 2"
        if test == "test_refund_amount_limits" and run >= 24:
            outcome = "fail"
            error = "AssertionError: amount 120.01 was accepted"
        if test == "test_search_orders" and run == 9:
            outcome = "fail"
            error = "ConnectionResetError: connection reset by peer"
        records.append({"run": run + 1, "commit": commit,
                        "runner": runner, "prev_test": prev or "-",
                        "test": test, "outcome": outcome,
                        "error": error, "ms": ms})
        prev = test

Path(__file__).with_name("test_runs.json").write_text(
    json.dumps(records, indent=0), encoding="utf-8")
