"""Writes golden/review_log.json and golden/time_study.json.

INVENTED pilot data for Chapter 27. Nothing here was measured on a
real team. Run this file to recreate both files.
"""
import json
from pathlib import Path

HERE = Path(__file__).parent
PLAN = {"bug_writer": (24, 11, 5), "log_summarizer": (12, 10, 8),
        "regression_map": (9, 6, 3)}
reviews = []
for agent, (acc, edit, rej) in PLAN.items():
    seq = (["accepted"] * acc + ["edited"] * edit + ["rejected"] * rej)
    # a fixed shuffle so the file does not look sorted
    seq = [seq[(i * 7) % len(seq)] for i in range(len(seq))]
    assert sorted(seq) == sorted(["accepted"] * acc + ["edited"] * edit
                                 + ["rejected"] * rej)
    for i, d in enumerate(seq, 1):
        reviews.append({"agent": agent, "item": f"{agent}-{i:02d}",
                        "decision": d})
(HERE / "review_log.json").write_text(
    json.dumps(reviews, indent=1), encoding="utf-8")

# minutes to write one bug report: by hand, and with the agent's
# draft including the time to review and fix it
manual = [14, 9, 18, 11, 25, 8, 16, 12, 20, 10, 15, 13]
agent = [8, 7, 9, 12, 11, 6, 10, 7, 9, 8, 9, 14]
pairs = [{"task": f"T{i}", "manual_min": m, "agent_min": a}
         for i, (m, a) in enumerate(zip(manual, agent), 1)]
(HERE / "time_study.json").write_text(
    json.dumps(pairs, indent=1), encoding="utf-8")
print(len(reviews), "reviews;", len(pairs), "paired tasks")
