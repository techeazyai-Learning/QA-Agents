"""Writes golden/service.log: an INVENTED incident for Chapter 17.

Nothing here comes from a real system. Run it to recreate the file.
"""
from pathlib import Path

LINES = []


def log(ts, level, req, msg, trace=()):
    LINES.append(f"2026-10-24T10:{ts}Z {level:<5} refund-service "
                 f"req={req} msg=\"{msg}\"")
    LINES.extend(trace)


log("15:00.120", "INFO", "a1f3", "refund requested order=1042 amount=20.00")
log("15:00.180", "INFO", "a1f3", "refund saved id=RF-7001 db_ms=31")
log("15:02.400", "INFO", "b7c2", "refund requested order=1050 amount=15.00")
log("15:02.455", "INFO", "b7c2", "refund saved id=RF-7002 db_ms=29")
log("15:09.870", "WARN", "-", "deprecated header X-Client-Version used")
log("15:30.002", "ERROR", "-", "healthcheck disk probe slow (non-critical) ms=900")
log("16:10.300", "INFO", "c9d4", "refund requested order=1061 amount=40.00")
log("16:10.390", "INFO", "c9d4", "refund saved id=RF-7003 db_ms=88")
log("16:41.010", "WARN", "-", "connection pool usage 16/20")
log("16:44.230", "INFO", "d2e5", "refund requested order=1070 amount=10.00")
log("16:44.980", "INFO", "d2e5", "refund saved id=RF-7004 db_ms=750")
log("16:50.100", "WARN", "-", "connection pool usage 19/20")
log("16:52.640", "INFO", "e6f1", "refund requested order=1071 amount=25.00")
log("16:57.700", "WARN", "-", "connection pool usage 20/20")
log("16:58.011", "ERROR", "e6f1", "could not get database connection "
    "waited_ms=5000",
    ["    PoolTimeoutError: timeout waiting for connection from pool",
     "        at refunds.save (refunds/service.py:88)",
     "        at refunds.submit (refunds/service.py:41)",
     "        at api.post_refund (api/routes.py:17)"])
log("16:58.012", "ERROR", "e6f1", "refund failed order=1071 status=500")
for i, (ts, order) in enumerate([("17:01.300", 1072), ("17:04.900", 1073),
                                 ("17:07.150", 1074), ("17:12.600", 1075)]):
    req = f"f{i}a{i}"
    log(ts, "INFO", req, f"refund requested order={order} amount=12.50")
    log(f"{ts[:3]}{int(ts[3:5]) + 5:02d}.{ts[6:]}", "ERROR", req,
        "could not get database connection waited_ms=5000",
        ["    PoolTimeoutError: timeout waiting for connection from pool",
         "        at refunds.save (refunds/service.py:88)"])
    log(f"{ts[:3]}{int(ts[3:5]) + 5:02d}.{ts[6:]}", "ERROR", req,
        f"refund failed order={order} status=500")
log("17:20.000", "WARN", "-", "email queue retry attempt=2 "
    "to=asha.ardent@example.test")
log("17:30.450", "WARN", "-", "connection pool usage 20/20")
log("17:31.000", "INFO", "-", "request headers authorization=Bearer "
    "abcdef0123456789abcdef0123456789")
log("17:40.010", "WARN", "-", "deprecated header X-Client-Version used")

Path(__file__).with_name("service.log").write_text(
    "\n".join(LINES) + "\n", encoding="utf-8")
