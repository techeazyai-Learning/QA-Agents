"""Run the Bug Report Completeness Checker from the command line.

    python hello_qa.py                    # offline, stand-in model
    python hello_qa.py --provider anthropic --model <model-name>
    python hello_qa.py --file my_report.txt
"""
import argparse
import json
import sys

from qa_agents.agents.bug_report_checker import check_bug_report
from qa_agents.fake_model import fake_bug_review
from qa_agents.llm import FunctionLLM, make_llm
from qa_agents.runlog import RunLog

SAMPLE = """Cart count badge is wrong after removing an item

Steps:
1. Add two items to the cart
2. Remove one item
Expected: badge shows 1.
Actual: badge still shows 2.
"""


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--provider", default="mock",
                    choices=["mock", "anthropic", "openai"])
    ap.add_argument("--model", default=None)
    ap.add_argument("--file", default=None)
    args = ap.parse_args(argv)

    report = SAMPLE
    if args.file:
        with open(args.file, encoding="utf-8") as fh:
            report = fh.read()
    if args.provider == "mock":
        llm = FunctionLLM(fake_bug_review)
    else:
        llm = make_llm(args.provider, args.model)

    log = RunLog("runs/hello_qa.jsonl")
    result = check_bug_report(llm, report, log=log)
    if not result.ok:
        print("Agent failed:", result.errors, file=sys.stderr)
        return 1
    print(json.dumps(result.data, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
