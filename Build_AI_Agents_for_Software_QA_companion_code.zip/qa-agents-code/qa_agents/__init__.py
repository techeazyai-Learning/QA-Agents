"""Companion code for the book on building AI agents for software QA."""

__version__ = "0.1.0"
