"""Score an agent against a labelled golden set."""
from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path

from .agents.bug_report_checker import FIELDS, check_bug_report


@dataclass
class Scores:
    cases: int
    failed_runs: int
    verdict_accuracy: float
    precision: float
    recall: float
    per_field: dict


def _ratio(num: int, den: int) -> float:
    return round(num / den, 3) if den else 1.0


def evaluate(llm, golden_path: str | Path) -> Scores:
    cases = json.loads(Path(golden_path).read_text(encoding="utf-8"))
    tp = fp = fn = right = failed = 0
    field_counts = {f: [0, 0, 0] for f in FIELDS}  # tp, fp, fn
    for case in cases:
        result = check_bug_report(llm, case["report"])
        if not result.ok:
            failed += 1
            fn += len(case["missing"])
            for f in case["missing"]:
                field_counts[f][2] += 1
            continue
        got = set(result.data["missing_fields"])
        want = set(case["missing"])
        right += result.data["verdict"] == case["verdict"]
        tp += len(got & want)
        fp += len(got - want)
        fn += len(want - got)
        for f in FIELDS:
            field_counts[f][0] += f in got and f in want
            field_counts[f][1] += f in got and f not in want
            field_counts[f][2] += f in want and f not in got
    per_field = {
        f: {"precision": _ratio(c[0], c[0] + c[1]),
            "recall": _ratio(c[0], c[0] + c[2])}
        for f, c in field_counts.items()
    }
    return Scores(len(cases), failed, _ratio(right, len(cases)),
                  _ratio(tp, tp + fp), _ratio(tp, tp + fn), per_field)
