"""A rule-based STAND-IN for a model, used to test the plumbing.

It is not an AI. It looks for keywords so the book's code can be run
and tested without network access or an API key. Its scores say
nothing about how a real model will perform.
"""
from __future__ import annotations

import json
import re

from .agents.bug_report_checker import FIELDS
from .agent import OPEN_TAG, CLOSE_TAG

_RULES = {
    "steps_to_reproduce": r"steps|^\s*1[.)]",
    "expected_result": r"expected|should",
    "actual_result": r"actual|instead|but got|nothing happens",
    "environment": (r"chrome|firefox|safari|android|ios|windows|"
                    r"macos|linux|version|build \d|v\d+\.\d+"),
    "evidence": r"screenshot|log|video|trace|attached|har file",
}


def fake_bug_review(system: str, user: str) -> str:
    start = user.find(OPEN_TAG) + len(OPEN_TAG)
    report = user[start:user.rfind(CLOSE_TAG)].strip()
    first_line = report.splitlines()[0] if report else ""
    missing = []
    if len(first_line.strip()) < 8:
        missing.append("title")
    for name in FIELDS[1:]:
        if not re.search(_RULES[name], report, re.I | re.M):
            missing.append(name)
    questions = [f"Can you add the {m.replace('_', ' ')}?"
                 for m in missing[:3]]
    return json.dumps({
        "verdict": "incomplete" if missing else "complete",
        "missing_fields": missing,
        "questions": questions,
        "summary": ("Report needs more detail." if missing
                    else "Report looks actionable."),
    })
