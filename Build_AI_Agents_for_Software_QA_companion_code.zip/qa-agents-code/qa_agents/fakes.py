"""Rule-based STAND-INS for a model, for Chapters 5 to 9.

These are not AI. They use keywords and arithmetic so the chapter
code can run and be tested offline. They are deliberately imperfect
so the scoring code has something to find. Their scores say nothing
about how a real model will perform on your material.
"""
from __future__ import annotations

import json
import re

from .agent import CLOSE_TAG, OPEN_TAG
from .guards import jaccard, tokens


def payload(user: str) -> str:
    """The text between the untrusted-input markers."""
    start = user.find(OPEN_TAG) + len(OPEN_TAG)
    return user[start:user.rfind(CLOSE_TAG)].strip()


def _find(pattern: str, text: str):
    m = re.search(pattern, text, re.I)
    return m.group(0) if m else None


def fake_requirement_review(system: str, user: str) -> str:
    findings = []
    lines = [ln for ln in payload(user).splitlines() if ": " in ln]
    texts = {ln.split(": ", 1)[0]: ln.split(": ", 1)[1]
             for ln in lines}
    for sid, text in texts.items():
        word = _find(r"\balways\b|\bnever\b", text)
        if word:
            findings.append({
                "statement_id": sid, "category": "untestable",
                "quote": word,
                "issue": f"'{word}' is an absolute that no test can "
                         "prove.",
                "question": "What availability target and "
                            "measurement window apply?"})
        term = _find(r"\bthe limit\b", text)
        if term:
            findings.append({
                "statement_id": sid, "category": "undefined_term",
                "quote": term,
                "issue": "The limit is not defined anywhere.",
                "question": "What is the limit, and who sets it?"})
    if texts and not any(re.search(r"error|invalid|reject|fail|"
                                   r"cannot|must not", t, re.I)
                         for t in texts.values()):
        first = next(iter(texts))
        findings.append({
            "statement_id": first, "category": "missing_error_case",
            "quote": texts[first][:40],
            "issue": "No statement says what happens on bad input.",
            "question": "What should the user see when input is "
                        "rejected?"})
    return json.dumps({"findings": findings})


def fake_generate_cases(system: str, user: str) -> str:
    body = payload(user)
    rules = json.loads(body.split("RULES:\n", 1)[1])
    cases = []

    def add(title, kind, rule, steps, expected, prio="P2"):
        cases.append({"title": title, "type": kind,
                      "rule_ids": [rule["id"]], "preconditions": [
                          "A signed-in support agent and a "
                          "delivered order"],
                      "steps": steps, "expected": expected,
                      "priority": prio})

    for r in rules:
        inp, f = r["suggested_inputs"], r["field"]
        for v in inp["valid"][:3]:
            add(f"{f} accepts {v or 'empty'}",
                "boundary" if r["kind"] == "range" else "positive", r,
                ["Open the refund form", f"Set {f} to '{v}'",
                 "Submit the form"],
                [f"The form accepts {f} = '{v}'"],
                "P1" if r["kind"] == "range" else "P2")
        for v in inp["invalid"][:3]:
            add(f"{f} rejects {v or 'empty'}",
                "negative" if r["kind"] != "range" else "boundary", r,
                ["Open the refund form", f"Set {f} to '{v}'",
                 "Submit the form"],
                [f"An error message is shown for {f}",
                 "No refund is created"])
        if r["kind"] == "behavior":
            add("Confirmation email after refund", "behavior", r,
                ["Submit a valid refund",
                 "Open the customer mailbox"],
                ["One confirmation email is received"], "P1")
    return json.dumps({"cases": cases})


_TYPE_GEN = {"uuid": "uuid", "email": "email", "int": "int_range",
             "decimal": "decimal_range", "enum": "choice",
             "date": "date_range", "string": "name"}


def fake_test_data(system: str, user: str) -> str:
    data = json.loads(payload(user))
    fields = data["data_dictionary"]
    recipes = []
    for f in fields:
        gen = _TYPE_GEN[f["type"]]
        if gen in ("int_range", "decimal_range"):
            valid = {"min": f["min"], "max": f["max"]}
        elif gen == "choice":
            valid = {"values": f["values"]}
        elif gen == "date_range":
            valid = {"start": f["min"], "end": f["max"]}
        else:
            valid = {}
        recipes.append({"field": f["name"], "purpose": "valid",
                        "generator": gen, "params": valid})
        if gen == "decimal_range":
            hi = float(f["max"])
            recipes.append({
                "field": f["name"], "purpose": "invalid",
                "generator": gen,
                "params": {"min": f"{hi + 1:.2f}",
                           "max": f"{hi + 10:.2f}"}})
        if gen == "choice":
            recipes.append({
                "field": f["name"], "purpose": "invalid",
                "generator": "choice",
                "params": {"values": ["not_a_listed_value"]}})
    needs = [{"entity": "order", "state": "delivered", "count": 5,
              "reason": "Refund cases need delivered orders."},
             {"entity": "order", "state": "cancelled", "count": 1,
              "reason": "Cancelled orders must be refused."}]
    return json.dumps({"needs": needs, "recipes": recipes})


def fake_rtm_links(system: str, user: str) -> str:
    items = json.loads(payload(user))
    links = []
    for item in items:
        req = item["requirement"]
        rt = tokens(req["text"])
        for cand in item["candidates"]:
            text = " ".join([cand["title"], *cand.get("steps", []),
                             *cand.get("expected", [])])
            score = jaccard(rt, tokens(text))
            if score >= 0.1:
                links.append({
                    "requirement_id": req["id"],
                    "test_id": cand["id"],
                    "strength": "full" if score >= 0.2 else "partial",
                    "quote": req["text"][:160],
                    "rationale": "Shares key terms with the "
                                 "requirement."})
    return json.dumps({"links": links})


def fake_case_review(system: str, user: str) -> str:
    cases = json.loads(payload(user))
    checks = [
        ("weak_expected", r"everything works correctly|works fine",
         "Expected result cannot be observed.",
         "Name the message, value or record to check."),
        ("multiple_behaviours", r"and then also|and also",
         "The case checks more than one behaviour.",
         "Split it into separate cases."),
        ("hidden_dependency", r"previous test|created earlier",
         "The case relies on another case having run.",
         "Create the data in a precondition."),
        ("ambiguous_step", r"reasonable|appropriate",
         "The step does not say which value to use.",
         "Give an exact value."),
    ]
    findings = []
    for c in cases:
        for cat, pat, issue, fix in checks:
            hit = _find(pat, c["text"])
            if hit:
                findings.append({"case_id": c["id"], "category": cat,
                                 "quote": hit, "issue": issue,
                                 "fix": fix})
    return json.dumps({"findings": findings})


# ---- Part III stand-ins -------------------------------------------

def _stem(word: str) -> str:
    return word[:-1] if word.endswith("s") and len(word) > 3 else word


def _words(text: str) -> set:
    return {_stem(w) for w in re.split(r"[^a-z0-9]+", text.lower())
            if w}


def fake_debrief(system: str, user: str) -> str:
    body = payload(user)
    areas = re.search(r"AREAS: (.*)", body).group(1).split(", ")
    notes = re.findall(r"^(N\d+) \[(\w+)\] (.*)$", body, re.M)
    out = {"bugs_to_report": [], "open_questions": [],
           "follow_up_charters": []}
    for nid, tag, text in notes:
        item = {"note_id": nid, "quote": text[:160], "text": text[:240]}
        if tag == "BUG":
            out["bugs_to_report"].append(item)
        elif tag == "Q":
            out["open_questions"].append(item)
        elif tag in ("IDEA", "RISK"):
            out["follow_up_charters"].append({
                "charter": "Explore: " + text[:120],
                "reason": f"Raised as {tag} in the session.",
                "note_id": nid, "quote": text[:160]})
    blob = " ".join(t for _, _, t in notes).lower()
    touched = [a for a in areas if a.split()[-1].lower() in blob]
    n_bugs = len(out["bugs_to_report"])
    out["summary"] = f"{len(notes)} notes; {n_bugs} bug candidates."
    out["areas_touched"] = touched
    return json.dumps(out)


def fake_impact(system: str, user: str) -> str:
    body = payload(user)
    files_part, tests_part = body.split("\nTEST IDS:\n")
    files = files_part.split("UNMAPPED FILES:\n")[1].splitlines()
    tests = tests_part.splitlines()
    skip = {"src", "py", "html", "test"}
    out = []
    for f in files:
        fw = _words(f) - skip
        hits = [t for t in tests if fw & (_words(t) - skip)][:3]
        name = f.rsplit("/", 1)[-1]
        out.append({"file": f, "test_ids": hits,
                    "new_test_idea": f"Add a test for {name}.",
                    "reason": "Guess from file names only."})
    return json.dumps({"suggestions": out})


_DRIFT_IMPACT = {
    "field_removed": ("Clients reading this field will get nothing.",
                      "Assert the field is present in the response."),
    "type_changed": ("Clients parsing the old type may fail.",
                     "Assert the field type with a schema check."),
    "param_added": ("Existing calls without it may be rejected.",
                    "Call without the new parameter; expect a clear "
                    "error."),
    "field_added": ("Old clients that omit the field may be rejected.",
                    "Send a request without the field; check the "
                    "response."),
    "enum_value_removed": ("Calls using the removed value fail.",
                           "Send the removed value; expect rejection."),
    "enum_value_added": ("Clients with fixed lists may mishandle it.",
                         "Make the API return the new value; check "
                         "the client."),
}


def fake_drift(system: str, user: str) -> str:
    items = []
    for m in re.finditer(r"^(C\d+) \[(breaking|risky)\] (\w+):",
                         payload(user), re.M):
        impact, test = _DRIFT_IMPACT.get(
            m.group(3), ("Clients may be affected.", "Add a test."))
        items.append({"change_id": m.group(1), "client_impact": impact,
                      "test_ideas": [test]})
    return json.dumps({"items": items})


_A11Y = {
    "button-name": ("People using screen readers hear only 'button'.",
                    "Give the button visible text or an aria-label.",
                    "Assert every button has an accessible name."),
    "image-alt": ("People who cannot see the image get no description.",
                  "Add an alt attribute; empty if purely decorative.",
                  "Assert every img has alt text."),
    "select-name": ("Screen reader users cannot tell what the list "
                    "is for.",
                    "Associate a visible label with the select.",
                    "Assert every form control has a label."),
    "color-contrast": ("People with low vision may not read the text.",
                       "Use a darker text colour on this background.",
                       "Run a contrast check in the pipeline."),
    "html-has-lang": ("Screen readers may use the wrong voice.",
                      "Add a lang attribute to the html element.",
                      "Assert the html element has lang."),
}


def fake_a11y(system: str, user: str) -> str:
    groups = json.loads(payload(user))
    items = []
    for g in groups:
        who, fix, test = _A11Y.get(g["rule_id"], (
            "Some users may be affected.",
            "Follow the rule's help text.",
            "Add an automated check for this rule."))
        items.append({"rule_id": g["rule_id"], "who_is_affected": who,
                      "fix": fix, "test_to_add": test})
    return json.dumps({"items": items})


def fake_payload_map(system: str, user: str) -> str:
    body = payload(user)
    api_text, ui_text = body.split("\nUNMAPPED PAGE LABELS:\n")
    api = json.loads(api_text.split("UNMAPPED API FIELDS:\n")[1])
    ui = json.loads(ui_text)
    used, proposals, hidden = set(), [], []
    for name, value in api.items():
        fw = _words(name)
        label = next((lb for lb in ui if lb not in used
                      and fw & _words(lb)), None)
        if label is None:
            hidden.append(name)
            continue
        used.add(label)
        if isinstance(value, list):
            fmt = "count"
        elif name.endswith("_on") or "date" in name:
            fmt = "date_dmy"
        elif name in ("total", "refunded", "refundable", "amount"):
            fmt = "money_usd"
        else:
            fmt = "as_is"
        proposals.append({"field": name, "label": label,
                          "format": fmt,
                          "reason": "Shares words with the label."})
    return json.dumps({"proposals": proposals, "not_displayed": hidden})


def fake_visual(system: str, user: str) -> str:
    data = json.loads(payload(user))
    note = data.get("note", "").lower()
    findings = []
    for r in data["regions"]:
        names = [e["element"] for e in r["elements"]]
        if note and ("layout" in note or "stack" in note):
            verdict = "likely_intentional"
        elif names:
            verdict = "likely_regression"
        else:
            verdict = "unclear"
        findings.append({"region_id": r["id"], "verdict": verdict,
                         "reason": "Based on the note and moved "
                                   "elements.",
                         "element": names[0] if names else ""})
    return json.dumps({"findings": findings})


# ---- Part IV stand-ins --------------------------------------------

def fake_bug_writer(system: str, user: str) -> str:
    from .agents.bug_writer import stems
    body = payload(user)
    notes_part, _, cand_part = body.partition("\n\nCANDIDATES:\n")
    notes = notes_part.split("NOTES:\n", 1)[1]
    lines = [ln.strip() for ln in notes.splitlines() if ln.strip()]
    env = next((ln for ln in lines if re.search(
        r"chrome|firefox|safari|build", ln, re.I)), "")
    expected = next((ln for ln in lines
                     if re.search(r"\bshould\b", ln, re.I)), "")
    actual = next((ln for ln in lines if re.search(
        r"accepted|twice|two times|overlap|no option|blank",
        ln, re.I)), lines[-1])
    steps = [ln for ln in lines if ln not in (env, expected)]
    missing = []
    if not env:
        missing.append("Which browser, device and build?")
    if not expected:
        missing.append("What did you expect to happen?")
    if not re.search(r"screenshot|log|video", notes, re.I):
        missing.append("Is there a screenshot or log?")
    severe = re.search(r"accepted|twice|two times", actual, re.I)
    checks = []
    for line in cand_part.splitlines():
        m = re.match(r"(\S+) \[\w+\] (.*)", line)
        if not m:
            continue
        score = (len(stems(notes) & stems(m.group(2)))
                 / max(1, len(stems(notes) | stems(m.group(2)))))
        verdict = ("duplicate" if score >= 0.2 else
                   "related" if score >= 0.1 else "different")
        checks.append({"bug_id": m.group(1), "verdict": verdict,
                       "reason": "Shares key words with the notes."})
    title = actual.rstrip(".")[:88]
    return json.dumps({"draft": {
        "title": title if len(title) >= 8 else "Unclear problem",
        "steps": steps[:12] or [lines[0]],
        "expected": expected or "Not stated in the notes.",
        "actual": actual, "environment": env or "Not stated.",
        "missing_info": missing[:5],
        "severity": "major" if severe else "minor",
        "severity_reason": ("Wrong money or duplicate customer "
                            "message." if severe
                            else "Cosmetic or low impact.")},
        "duplicate_checks": checks})


def fake_log(system: str, user: str) -> str:
    body = payload(user)
    lines = {int(m.group(1)): m.group(2) for m in re.finditer(
        r"^L(\d+): (.*)$", body, re.M)}
    pool = [n for n, t in lines.items() if "pool" in t.lower()][:3]
    first = int(re.search(r"MOST FREQUENT ERROR GROUP: L(\d+)",
                          body).group(1))
    evidence = [{"line": n, "quote": "pool"} for n in pool]
    if first in lines and first not in pool:
        evidence.append({"line": first,
                         "quote": "could not get database connection"
                         if "could not get database" in lines[first]
                         else lines[first][-30:]})
    hyp = [{"cause": "Database connection pool was exhausted, so "
                     "saves timed out and refunds failed.",
            "evidence": evidence or [{"line": first,
                                      "quote": lines[first][-20:]}],
            "confidence": "high" if len(evidence) >= 2 else "low",
            "next_check": "Check pool size and slow queries around "
                          "that minute."}]
    unrelated = []
    for m in re.finditer(r"^(K\d+) (?:ERROR|WARN|INFO) x\d+ \S+ "
                         r"(.*)$", body, re.M):
        if re.search(r"healthcheck|deprecated", m.group(2)):
            unrelated.append(m.group(1))
    return json.dumps({"summary": "Refund saves began failing after "
                       "the database connection pool filled up.",
                       "hypotheses": hyp,
                       "likely_unrelated": unrelated})


def fake_regression(system: str, user: str) -> str:
    from .agents.bug_writer import stems
    data = json.loads(payload(user))
    bug, cands = data["bug"], data["candidates"]
    want = stems(bug["title"] + " " + bug["text"])
    best, score = None, 0.0
    for c in cands:
        s = (len(want & stems(c["title"] + " " + c["summary"]))
             / len(want | stems(c["title"] + " " + c["summary"])))
        if s > score:
            best, score = c, s
    first = re.split(r"(?<=[a-z])\.\s", bug["text"])[0]
    if best and score >= 0.3:
        return json.dumps({
            "bug_id": bug["id"], "outcome": "covered",
            "test_id": best["id"], "level": "none", "steps": [],
            "explanation": "The test covers this behaviour.",
            "new_test_title": "", "expected": ""})
    new = {"new_test_title": "Regression: " + bug["title"][:80],
           "level": "api", "steps": [first[:190]],
           "expected": "The behaviour in the bug no longer occurs."}
    if best and score >= 0.1:
        return json.dumps({
            "bug_id": bug["id"], "outcome": "partial",
            "test_id": best["id"],
            "explanation": "Checks nearby behaviour, not this case.",
            **new})
    return json.dumps({"bug_id": bug["id"], "outcome": "gap",
                       "test_id": "",
                       "explanation": "No candidate is relevant.",
                       **new})


def fake_flaky(system: str, user: str) -> str:
    stats = json.loads(payload(user))
    items = []
    for test, s in stats.items():
        err = s["errors"][0] if s["errors"] else ""
        runner = max(s["by"]["runner"].values(),
                     key=lambda v: v["rate"])["rate"]
        prev = max(s["by"]["prev_test"].values(),
                   key=lambda v: v["rate"])["rate"]
        if "Timeout" in err and runner >= 2 * s["fail_rate"]:
            cat = "environment"
        elif "found 2" in err and prev >= 2 * s["fail_rate"]:
            cat = "shared_state"
        elif "Connection" in err:
            cat = "external_dependency"
        elif "Timeout" in err:
            cat = "timing"
        else:
            cat = "unknown"
        items.append({
            "test": test, "category": cat,
            "evidence_quote": err[:40] if cat != "unknown" else "",
            "reasoning": f"The error and the statistics fit {cat}.",
            "experiment": "Re-run with one factor changed at a time."})
    return json.dumps({"items": items})


def fake_perf(system: str, user: str) -> str:
    body = payload(user)
    purposes = {
        "load": "Check that today's peak is handled within the target.",
        "growth": "Check that planned growth still meets the target.",
        "spike": "See how the service copes with a sudden burst and "
                 "whether it recovers.",
        "soak": "Look for slow leaks that only show after a long "
                "run."}
    out, current = [], None
    for ln in body.splitlines():
        m = re.match(r"^(S\d+) (\w+) \(", ln)
        if m:
            current = {"id": m.group(1),
                       "purpose": purposes[m.group(2)],
                       "watch": ["response time", "error rate",
                                 "database connections"],
                       "risks": [], "_top": (None, -1.0)}
            out.append(current)
            continue
        e = re.match(r"^  (.+): ([\d.]+) per second$", ln)
        if e and current is not None:
            rate = float(e.group(2))
            if rate > current["_top"][1]:
                current["_top"] = (e.group(1), rate)
    for s in out:
        name = s.pop("_top")[0]
        s["risks"] = [{"endpoint": name, "risk":
                       "The busiest endpoint is the first to slow "
                       "down under this scenario."}]
    return json.dumps({"scenarios": out, "questions": [
        "Where did the hourly traffic figures come from, and do they "
        "include the busiest day?",
        "Does the test environment match production in size and "
        "data?"]})


_SEC_IDEAS = {
    "object_reference": (
        "Open an order that belongs to another customer or account "
        "by changing the order number in the address.",
        "The service refuses, or shows nothing, and the attempt is "
        "recorded.", "both"),
    "roles": (
        "As an agent, try to approve a refund above the limit, "
        "through the screen and by calling the interface directly.",
        "Only an admin can approve; the interface refuses the "
        "agent's call too.", "api"),
    "sign_in": (
        "Try many wrong passwords in a row, and reuse an old session "
        "after signing out.",
        "Repeated failures are slowed or locked; a signed-out "
        "session no longer works.", "both"),
    "free_text": (
        "Enter a note far longer than allowed, with characters that "
        "have special meaning in web pages and queries.",
        "The note is stored and shown as plain text; over-length "
        "input is refused.", "both"),
    "file_upload": (
        "Attach a file that is not an image, a larger file than "
        "allowed and an image with a misleading name.",
        "Only permitted types and sizes are accepted; nothing "
        "uploaded is run.", "both"),
    "money": (
        "Submit the same refund twice in quick succession, and an "
        "amount with unusual formatting.",
        "Only one refund is created and the limit rules hold.",
        "api"),
    "email_output": (
        "Put line breaks and markup into the note and check the "
        "confirmation email that results.",
        "The email shows only the intended text and no extra "
        "headers or markup.", "api"),
    "audit": (
        "Perform a refund, a refused refund and an approval, then "
        "read the audit log.",
        "Each action appears once with the right person and time.",
        "api")}


def fake_security(system: str, user: str) -> str:
    body = payload(user)
    ideas = []
    for m in re.finditer(r'^(T\d+) (\w+) \[.*?\] sentence: "(.*)"$',
                         body, re.M):
        ref, trait, sentence = m.groups()
        idea, result, level = _SEC_IDEAS[trait]
        ideas.append({"trait": ref, "feature_quote": sentence,
                      "test_idea": idea, "secure_result": result,
                      "level": level})
    return json.dumps({"ideas": ideas})


def fake_judge(system: str, user: str) -> str:
    from .agents.bug_writer import stems
    body = payload(user)
    q = re.search(r"^QUESTION: (.*)$", body, re.M).group(1)
    a = re.search(r"^ANSWER: (.*)$", body, re.M).group(1)
    findings = body.split("AUTOMATIC FINDINGS:", 1)[1]
    clean = re.sub(r"\[S\d+\]", "", a).strip()
    aw, qw = stems(clean), stems(q)
    bad = "ungrounded_number" in findings \
        or "unknown_citation" in findings
    faith = 2 if bad else (4 if "[S" in a else 3)
    comp = 4 if len(aw & qw) >= 2 else 2
    return json.dumps({"scores": [
        {"criterion": "faithfulness", "score": faith,
         "evidence": clean[:60],
         "reason": "Judged by word overlap with the sources."},
        {"criterion": "completeness", "score": comp,
         "evidence": clean[:60],
         "reason": "Judged by word overlap with the question."}]})


def fake_readiness(system: str, user: str) -> str:
    body = payload(user)
    meaning = {
        "fail": "The criterion is not met, so the release owner has "
                "a known problem to resolve or accept.",
        "unknown": "There is no evidence either way, so this "
                   "criterion cannot be counted as met.",
        "waived": "A named person accepted this gap, which is "
                  "recorded but still a gap."}
    options = {
        "fail": ["Fix the cause and re-run the check.",
                 "Accept the gap in writing with a named owner."],
        "unknown": ["Collect the missing evidence and re-check.",
                    "Treat the criterion as failed until it "
                    "arrives."],
        "waived": ["Confirm the waiver is still valid.",
                   "Set a date to review it."]}
    items = []
    for m in re.finditer(r"^(G\d+) \[[\w-]+\] (fail|unknown|waived):",
                         body, re.M):
        gate, status = m.groups()
        items.append({"gate": gate, "meaning": meaning[status],
                      "options": options[status],
                      "questions": ["Who owns the next step?"]})
    return json.dumps({
        "summary": "Some criteria are not met or have no evidence. "
                   "The release owner decides what to do.",
        "items": items})


def fake_narrator(system: str, user: str) -> str:
    body = payload(user)
    aud = re.search(r"^AUDIENCE: (\w+)", body, re.M).group(1)
    lines = re.findall(r"^(F\d+)( MUST)?: (.*)$", body, re.M)
    must = [(i, t) for i, m, t in lines if m]
    rel = re.search(r"Release ([\d.]+)", body).group(1)
    heads = {"executive": f"Release {rel}: criteria not met",
             "engineering": f"Release {rel}: gates that need work",
             "support": f"Release {rel}: known issues"}
    return json.dumps({
        "headline": heads[aud],
        "sentences": [{"text": t, "facts": [i]} for i, t in must]})


def fake_router(system: str, user: str) -> str:
    """One stand-in that picks the right fake from the instructions."""
    if "flaky tests" in system:
        return fake_flaky(system, user)
    if "readiness scorecard" in system:
        return fake_readiness(system, user)
    if "short test report" in system:
        return fake_narrator(system, user)
    raise ValueError("no stand-in for this agent")
