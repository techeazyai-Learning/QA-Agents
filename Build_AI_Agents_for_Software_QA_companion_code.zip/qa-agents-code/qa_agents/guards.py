"""Output guards shared by several agents."""
from __future__ import annotations

import re
from typing import Iterable, Mapping


def norm(text: str) -> str:
    """Lower-case and collapse whitespace, for fair comparisons."""
    return " ".join(str(text).lower().split())


def quote_in(source: str, quote: str) -> bool:
    """True if `quote` is in `source`, ignoring case and spacing."""
    q = norm(quote)
    return bool(q) and q in norm(source)


def check_quotes(findings: Iterable[dict], sources: Mapping[str, str],
                 id_key: str = "statement_id",
                 quote_key: str = "quote") -> list:
    """Every finding must cite a real source and quote it truthfully."""
    errors = []
    for i, item in enumerate(findings):
        sid = item.get(id_key)
        if sid not in sources:
            errors.append(f"finding {i}: unknown {id_key} {sid!r}")
        elif not quote_in(sources[sid], item.get(quote_key, "")):
            errors.append(
                f"finding {i}: quote is not in {sid}; quote the "
                "exact words"
            )
    return errors


def check_known_ids(values: Iterable[str], known: Iterable[str],
                    label: str) -> list:
    known_set = set(known)
    return [f"{label} {v!r} does not exist"
            for v in values if v not in known_set]


def duplicates(values: Iterable[str]) -> list:
    seen, dupes = set(), []
    for v in values:
        key = norm(v)
        if key in seen and v not in dupes:
            dupes.append(v)
        seen.add(key)
    return dupes


_WORD = re.compile(r"[a-z0-9']+")
_STOP = frozenset(
    "a an and are as at be by can for from has have if in is it its "
    "of on or that the their then this to was were when which will "
    "with must should shall may not no".split()
)


def tokens(text: str) -> set:
    """Content words of a text, without common filler words."""
    return {w for w in _WORD.findall(text.lower())
            if w not in _STOP and len(w) > 1}


def jaccard(a: set, b: set) -> float:
    if not a or not b:
        return 0.0
    return len(a & b) / len(a | b)
