"""Provider-neutral model access.

Every agent talks to a model through one method:

    complete(system, user, max_tokens=...) -> str

Swap the object, keep the agent.
"""
from __future__ import annotations

import os
from typing import Callable, Protocol, Sequence, Union


class LLM(Protocol):
    def complete(self, system: str, user: str, *,
                 max_tokens: int = 1024) -> str: ...


Reply = Union[str, Callable[[str, str], str]]


class MockLLM:
    """Test double: returns scripted replies, records every call."""

    def __init__(self, replies: Sequence[Reply]):
        self._replies = list(replies)
        self.calls: list[dict] = []

    def complete(self, system, user, *, max_tokens=1024):
        self.calls.append(
            {"system": system, "user": user, "max_tokens": max_tokens}
        )
        if not self._replies:
            raise RuntimeError("MockLLM has no replies left")
        reply = self._replies.pop(0)
        return reply(system, user) if callable(reply) else reply


class FunctionLLM:
    """Test double: answers every call with fn(system, user)."""

    def __init__(self, fn: Callable[[str, str], str]):
        self._fn = fn
        self.calls = 0

    def complete(self, system, user, *, max_tokens=1024):
        self.calls += 1
        return self._fn(system, user)


def _model_name(model: str | None) -> str:
    name = model or os.environ.get("QA_AGENT_MODEL")
    if not name:
        raise ValueError(
            "Pass model=... or set the QA_AGENT_MODEL variable. "
            "Model names change, so the code never hard-codes one."
        )
    return name


class AnthropicLLM:
    """Adapter for the `anthropic` Python SDK (Messages API)."""

    def __init__(self, model: str | None = None, client=None):
        self.model = _model_name(model)
        if client is None:
            import anthropic  # reads ANTHROPIC_API_KEY itself

            client = anthropic.Anthropic()
        self.client = client

    def complete(self, system, user, *, max_tokens=1024):
        msg = self.client.messages.create(
            model=self.model,
            max_tokens=max_tokens,
            system=system,
            messages=[{"role": "user", "content": user}],
        )
        return "".join(
            block.text for block in msg.content
            if getattr(block, "type", "") == "text"
        )


class OpenAILLM:
    """Adapter for the `openai` Python SDK (Chat Completions)."""

    def __init__(self, model: str | None = None, client=None):
        self.model = _model_name(model)
        if client is None:
            import openai  # reads OPENAI_API_KEY itself

            client = openai.OpenAI()
        self.client = client

    def complete(self, system, user, *, max_tokens=1024):
        resp = self.client.chat.completions.create(
            model=self.model,
            max_completion_tokens=max_tokens,
            messages=[
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
        )
        return resp.choices[0].message.content or ""


def make_llm(provider: str, model: str | None = None) -> LLM:
    if provider == "anthropic":
        return AnthropicLLM(model)
    if provider == "openai":
        return OpenAILLM(model)
    raise ValueError(f"Unknown provider: {provider}")
