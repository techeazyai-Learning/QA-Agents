"""Measure what an agent is worth, with honest uncertainty.

Plain arithmetic on records that people write down: what a reviewer
did with each suggestion, and how long a task took with and without
the agent. Small samples get a warning, not a verdict.
"""
from __future__ import annotations

import math
import statistics

SMALL = 30      # below this many records, say "indicative only"
DECISIONS = ("accepted", "edited", "rejected")


def wilson(successes: int, n: int, z: float = 1.96) -> tuple:
    """Wilson score interval for a proportion (95% for z=1.96)."""
    if n == 0:
        return (0.0, 1.0)
    p = successes / n
    denom = 1 + z * z / n
    centre = (p + z * z / (2 * n)) / denom
    half = z * math.sqrt(p * (1 - p) / n
                         + z * z / (4 * n * n)) / denom
    return (round(max(0.0, centre - half), 3),
            round(min(1.0, centre + half), 3))


def _rate(k: int, n: int) -> dict:
    lo, hi = wilson(k, n)
    return {"rate": round(k / n, 3) if n else 0.0,
            "low": lo, "high": hi}


def review_summary(records: list) -> dict:
    """Per agent: how often reviewers accept, edit or reject."""
    out: dict = {}
    for r in records:
        if r["decision"] not in DECISIONS:
            raise ValueError(f"unknown decision {r['decision']!r}")
        out.setdefault(r["agent"], []).append(r["decision"])
    summary = {}
    for agent, ds in out.items():
        n = len(ds)
        c = {d: ds.count(d) for d in DECISIONS}
        summary[agent] = {
            "n": n, "counts": c,
            "accepted": _rate(c["accepted"], n),
            "useful": _rate(c["accepted"] + c["edited"], n),
            "rejected": _rate(c["rejected"], n),
            "note": "indicative only" if n < SMALL else ""}
    return summary


def time_summary(pairs: list) -> dict:
    """Paired minutes: the same task by hand and with the agent."""
    n = len(pairs)
    if n == 0:
        raise ValueError("no tasks")
    saving = [p["manual_min"] - p["agent_min"] for p in pairs]
    faster = sum(1 for s in saving if s > 0)
    return {"n": n,
            "median_manual": statistics.median(
                p["manual_min"] for p in pairs),
            "median_agent": statistics.median(
                p["agent_min"] for p in pairs),
            "median_saving": statistics.median(saving),
            "slower_or_equal": n - faster,
            "faster_share": _rate(faster, n),
            "note": "indicative only" if n < SMALL else ""}


def cost_per_item(items: int, tokens_in: int, tokens_out: int,
                  price_in_per_m: float,
                  price_out_per_m: float) -> float:
    """Model cost per item. Prices are yours to supply."""
    if items <= 0:
        raise ValueError("items must be positive")
    total = (tokens_in * price_in_per_m
             + tokens_out * price_out_per_m) / 1_000_000
    return round(total / items, 6)


def net_value(items_per_month: int, minutes_saved: float,
              hourly_cost: float, model_cost_per_month: float,
              upkeep_hours_per_month: float) -> dict:
    """Monthly value after the agent's own costs. All inputs are
    assumptions that you must be able to defend."""
    gross = items_per_month * minutes_saved / 60 * hourly_cost
    upkeep = upkeep_hours_per_month * hourly_cost
    net = gross - model_cost_per_month - upkeep
    return {"gross": round(gross, 2),
            "model_cost": round(model_cost_per_month, 2),
            "upkeep": round(upkeep, 2), "net": round(net, 2)}
