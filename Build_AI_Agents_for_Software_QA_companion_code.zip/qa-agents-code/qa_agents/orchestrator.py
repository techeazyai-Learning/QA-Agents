"""Run several agents as one pipeline, with limits and an audit trail.

Each step declares what it needs, its autonomy level (L0 observe,
L1 draft, L2 act with approval, L3 act with audit) and how many
model calls it may make. The runner orders the steps, enforces the
limits, never skips a failure silently and logs every step.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Optional

from .llm import LLM
from .runlog import RunLog

LEVELS = {"L0": 0, "L1": 1, "L2": 2, "L3": 3}


class BudgetExceeded(RuntimeError):
    pass


class Budget:
    """Model calls left for the whole run."""

    def __init__(self, total: Optional[int] = None):
        self.total = total
        self.used = 0

    def take(self) -> None:
        if self.total is not None and self.used >= self.total:
            raise BudgetExceeded(
                f"run budget of {self.total} model calls used up")
        self.used += 1


class StepLLM:
    """The model as one step sees it: counted and capped."""

    def __init__(self, inner: LLM, budget: Budget, limit: int):
        self.inner, self.budget, self.limit = inner, budget, limit
        self.calls = 0

    def complete(self, system, user, *, max_tokens=1024):
        if self.calls >= self.limit:
            raise BudgetExceeded(
                f"step limit of {self.limit} model calls reached")
        self.budget.take()
        self.calls += 1
        return self.inner.complete(system, user, max_tokens=max_tokens)


@dataclass
class Step:
    name: str
    fn: Callable[[dict], Any]
    needs: tuple = ()
    level: str = "L0"
    max_calls: int = 0
    about: str = ""


@dataclass
class StepResult:
    name: str
    status: str
    level: str
    calls: int = 0
    detail: str = ""
    output: Any = None


@dataclass
class RunReport:
    results: dict = field(default_factory=dict)
    order: list = field(default_factory=list)
    calls: int = 0

    @property
    def ok(self) -> bool:
        bad = {"failed", "refused", "skipped"}
        return not any(r.status in bad for r in self.results.values())

    @property
    def complete(self) -> bool:
        return all(r.status == "ok" for r in self.results.values())

    def table(self) -> list:
        return [(n, self.results[n].level, self.results[n].status,
                 self.results[n].calls, self.results[n].detail)
                for n in self.order]


class Pipeline:
    def __init__(self, steps: list):
        self.steps = list(steps)

    def validate(self) -> list:
        errors, names = [], [s.name for s in self.steps]
        for n in set(names):
            if names.count(n) > 1:
                errors.append(f"duplicate step {n!r}")
        for s in self.steps:
            if s.level not in LEVELS:
                errors.append(f"{s.name}: unknown level {s.level!r}")
            for d in s.needs:
                if d not in names:
                    errors.append(f"{s.name}: needs unknown step {d!r}")
        if not errors and self._cycle():
            errors.append("the steps contain a cycle")
        return errors

    def _cycle(self) -> bool:
        try:
            self.order()
        except ValueError:
            return True
        return False

    def order(self) -> list:
        """Dependency order; ties keep the order the steps are given."""
        left = {s.name: set(s.needs) for s in self.steps}
        out: list = []
        while left:
            ready = [s.name for s in self.steps
                     if s.name in left and not left[s.name]]
            if not ready:
                raise ValueError("cycle")
            n = ready[0]
            out.append(n)
            del left[n]
            for deps in left.values():
                deps.discard(n)
        return out

    def run(self, llm: LLM, log: RunLog, *, approved=(),
            max_level: str = "L1",
            total_calls: Optional[int] = None) -> RunReport:
        problems = self.validate()
        if problems:
            raise ValueError("; ".join(problems))
        by_name = {s.name: s for s in self.steps}
        budget, report = Budget(total_calls), RunReport()
        report.order = self.order()
        for name in report.order:
            step = by_name[name]
            res = self._one(step, report, llm, log, budget,
                            set(approved), max_level)
            report.results[name] = res
            log.event("step", step=name, status=res.status,
                      level=res.level, calls=res.calls,
                      detail=res.detail)
        report.calls = budget.used
        return report

    def _one(self, step, report, llm, log, budget, approved,
             max_level) -> StepResult:
        def make(status, detail="", **kw):
            return StepResult(step.name, status, step.level,
                              detail=detail, **kw)

        for d in step.needs:
            up = report.results[d].status
            if up in ("failed", "refused", "skipped"):
                return make("skipped", f"upstream step {d} is {up}")
            if up in ("pending_approval", "waiting"):
                return make("waiting", f"upstream step {d} is {up}")
        if LEVELS[step.level] > LEVELS[max_level]:
            return make("refused", f"level {step.level} is above the "
                        f"allowed level {max_level}")
        if LEVELS[step.level] >= LEVELS["L2"] \
                and step.name not in approved:
            return make("pending_approval", step.about
                        or "waiting for a person to approve")
        sllm = StepLLM(llm, budget, step.max_calls)
        ctx = {"llm": sllm, "log": log,
               "out": {d: report.results[d].output
                       for d in step.needs}}
        try:
            output = step.fn(ctx)
        except BudgetExceeded as exc:
            return make("failed", str(exc), calls=sllm.calls)
        except Exception as exc:  # a step must never crash the run
            return make("failed", f"{type(exc).__name__}: {exc}",
                        calls=sllm.calls)
        return make("ok", calls=sllm.calls, output=output)
