"""Basic redaction before text leaves your machine.

This is a first line of defence, not a guarantee. Review the patterns
against your own data and add the identifiers your company uses.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

_PATTERNS = [
    ("SECRET", re.compile(
        r"(?i)\b(password|passwd|pwd|secret|api[_-]?key|token)\b"
        r"\s*[:=]\s*\S+")),
    ("BEARER", re.compile(r"(?i)\bbearer\s+[A-Za-z0-9._~+/=-]{16,}")),
    ("EMAIL", re.compile(
        r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")),
    ("LONGTOKEN", re.compile(r"\b[A-Za-z0-9_-]{32,}\b")),
    ("PHONE", re.compile(
        r"(?<![\w.])(?:\+?\d{1,3}[\s-]?)?\(?\d{3}\)?[\s-]?\d{3}"
        r"[\s-]?\d{4}(?![\w.])")),
]


@dataclass
class Redacted:
    text: str
    counts: dict = field(default_factory=dict)

    @property
    def total(self) -> int:
        return sum(self.counts.values())


def redact(text: str) -> Redacted:
    counts: dict[str, int] = {}
    for label, pattern in _PATTERNS:
        text, n = pattern.subn(f"[REDACTED_{label}]", text)
        if n:
            counts[label] = n
    return Redacted(text, counts)
