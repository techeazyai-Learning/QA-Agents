"""A release-day pipeline built from agents of Parts IV to VI.

Triage the flaky tests, compute the readiness scorecard, draft an
executive and an engineering report, assemble a packet for review
and, only after a named approval, copy it to an outbox folder.
"""
from __future__ import annotations

from pathlib import Path

from .agents import flaky_triage, release_readiness, report_narrator
from .orchestrator import Pipeline, Step


def build(records: list, evidence: dict, gates: dict,
          outbox: Path) -> Pipeline:
    def triage(ctx):
        res = flaky_triage.triage(ctx["llm"], records, ctx["log"])
        if not res.ok:
            raise RuntimeError("; ".join(res.errors))
        return {"kinds": res.kinds, "actions": res.actions}

    def scorecard(ctx):
        res = release_readiness.scorecard(ctx["llm"], evidence, gates,
                                          ctx["log"])
        if not res.ok:
            raise RuntimeError("; ".join(res.errors))
        return {"rows": res.rows, "overall": res.overall}

    def report(audience):
        def run(ctx):
            rows = ctx["out"]["scorecard"]["rows"]
            res = report_narrator.narrate(ctx["llm"], audience,
                                          evidence, rows, ctx["log"])
            if not res.ok:
                raise RuntimeError("; ".join(res.errors))
            return report_narrator.to_text(res.report)
        return run

    def packet(ctx):
        up = ctx["out"]
        proposals = [f"- {t}: {a}" for t, a in
                     up["triage"]["actions"].items()]
        return "\n\n".join([
            f"# Release packet {evidence['release']} (draft)",
            "## Executive report\n" + up["report_exec"],
            "## Engineering report\n" + up["report_eng"],
            "## Agent proposals on tests (a person decides)\n"
            + "\n".join(proposals)])

    def publish(ctx):
        outbox.mkdir(parents=True, exist_ok=True)
        target = outbox / f"release_{evidence['release']}.md"
        target.write_text(ctx["out"]["packet"], encoding="utf-8")
        return str(target)

    return Pipeline([
        Step("triage", triage, level="L0", max_calls=3,
             about="Classify flaky and broken tests"),
        Step("scorecard", scorecard, level="L0", max_calls=3),
        Step("report_exec", report("executive"),
             needs=("scorecard",), level="L1", max_calls=3),
        Step("report_eng", report("engineering"),
             needs=("scorecard",), level="L1", max_calls=3),
        Step("packet", packet, level="L1",
             needs=("triage", "report_exec", "report_eng")),
        Step("publish", publish, needs=("packet",), level="L2",
             about="Copy the packet to the outbox folder")])
