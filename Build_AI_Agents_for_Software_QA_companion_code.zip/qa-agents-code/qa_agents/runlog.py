"""An append-only JSON Lines audit trail for agent runs."""
from __future__ import annotations

import json
import time
import uuid
from pathlib import Path


class RunLog:
    def __init__(self, path: str | Path, run_id: str | None = None):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.run_id = run_id or uuid.uuid4().hex[:8]

    def event(self, kind: str, **data) -> None:
        record = {"run": self.run_id, "t": round(time.time(), 3),
                  "kind": kind, **data}
        with self.path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(record, ensure_ascii=False) + "\n")
