"""A small JSON-Schema-style validator, using only the standard library.

It supports the keywords the book's agents need: type, properties,
required, additionalProperties, items, enum, minimum, maximum,
minLength, maxLength, minItems and maxItems.
"""
from __future__ import annotations

import json
import re


def extract_json(text: str) -> dict:
    """Pull the first JSON object out of a model reply.

    Models sometimes wrap JSON in a code fence or add a sentence
    before it. We accept that, but nothing else.
    """
    body = text.strip()
    fence = re.match(r"^```[a-zA-Z]*\s*\n(.*?)\n?```\s*$", body, re.S)
    if fence:
        body = fence.group(1)
    start, end = body.find("{"), body.rfind("}")
    if start == -1 or end < start:
        raise ValueError("no JSON object found in the reply")
    value = json.loads(body[start:end + 1])
    if not isinstance(value, dict):
        raise ValueError("top-level JSON value must be an object")
    return value


_TYPES = {
    "object": dict,
    "array": list,
    "string": str,
    "boolean": bool,
}


def _is_type(value, name: str) -> bool:
    if name == "integer":
        return isinstance(value, int) and not isinstance(value, bool)
    if name == "number":
        return (isinstance(value, (int, float))
                and not isinstance(value, bool))
    return isinstance(value, _TYPES[name])


def validate(value, schema: dict, path: str = "$") -> list[str]:
    """Return a list of human-readable problems (empty means valid)."""
    errors: list[str] = []
    expected = schema.get("type")
    if expected and not _is_type(value, expected):
        return [f"{path}: expected {expected}, "
                f"got {type(value).__name__}"]
    if "enum" in schema and value not in schema["enum"]:
        errors.append(f"{path}: {value!r} not in {schema['enum']}")
    if isinstance(value, str):
        if len(value) < schema.get("minLength", 0):
            errors.append(f"{path}: string is too short")
        if len(value) > schema.get("maxLength", 10**9):
            errors.append(f"{path}: string is too long")
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        if value < schema.get("minimum", float("-inf")):
            errors.append(f"{path}: below minimum")
        if value > schema.get("maximum", float("inf")):
            errors.append(f"{path}: above maximum")
    if isinstance(value, list):
        if len(value) < schema.get("minItems", 0):
            errors.append(f"{path}: too few items")
        if len(value) > schema.get("maxItems", 10**9):
            errors.append(f"{path}: too many items")
        item_schema = schema.get("items")
        if item_schema:
            for i, item in enumerate(value):
                errors += validate(item, item_schema, f"{path}[{i}]")
    if isinstance(value, dict):
        props = schema.get("properties", {})
        for key in schema.get("required", []):
            if key not in value:
                errors.append(f"{path}: missing required '{key}'")
        for key, sub in props.items():
            if key in value:
                errors += validate(value[key], sub, f"{path}.{key}")
        if schema.get("additionalProperties") is False:
            for key in value:
                if key not in props:
                    errors.append(f"{path}: unexpected key '{key}'")
    return errors
