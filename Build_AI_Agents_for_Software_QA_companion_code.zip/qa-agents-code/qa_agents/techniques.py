"""Exact test-design arithmetic. Code does this, not the model."""
from __future__ import annotations

from decimal import Decimal


def _d(x) -> Decimal:
    return Decimal(str(x))


def boundary_values(minimum, maximum, step="1") -> list:
    """The six classic values around a closed range [min, max]."""
    lo, hi, s = _d(minimum), _d(maximum), _d(step)
    if lo > hi:
        raise ValueError("minimum is greater than maximum")
    values = {lo - s, lo, lo + s, hi - s, hi, hi + s}
    return [format(v.normalize(), "f") for v in sorted(values)]


def in_range(value, minimum, maximum) -> bool:
    return _d(minimum) <= _d(value) <= _d(maximum)


def suggested_inputs(rule: dict) -> dict:
    """Valid and invalid inputs for one structured rule."""
    kind = rule["kind"]
    if kind == "range":
        step = rule.get("step", "1")
        vals = boundary_values(rule["min"], rule["max"], step)
        valid = [v for v in vals
                 if in_range(v, rule["min"], rule["max"])]
        return {"valid": valid,
                "invalid": [v for v in vals if v not in valid]}
    if kind == "enum":
        return {"valid": list(rule["values"]),
                "invalid": ["", "not_a_listed_value"]}
    if kind == "state":
        return {"valid": list(rule["allowed"]),
                "invalid": list(rule["others"])}
    return {"valid": [], "invalid": []}
