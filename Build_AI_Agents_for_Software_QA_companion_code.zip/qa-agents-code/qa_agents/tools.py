"""A tiny, provider-neutral tool-use loop with safety rails."""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Callable, Optional

from .llm import LLM
from .runlog import RunLog
from .schema import extract_json


@dataclass
class Tool:
    name: str
    description: str
    func: Callable[..., object]
    read_only: bool = True


class ToolRegistry:
    def __init__(self):
        self._tools: dict[str, Tool] = {}

    def register(self, tool: Tool) -> None:
        self._tools[tool.name] = tool

    def get(self, name: str) -> Optional[Tool]:
        return self._tools.get(name)

    def describe(self) -> str:
        lines = []
        for t in self._tools.values():
            mode = "read-only" if t.read_only else "WRITES"
            lines.append(f"- {t.name} ({mode}): {t.description}")
        return "\n".join(lines)


PROTOCOL = (
    "Work in steps. On each step reply with ONE JSON object:\n"
    '  {"action": "tool", "tool": "<name>", "args": {...}}\n'
    "to call a tool, or\n"
    '  {"action": "final", "result": {...}}\n'
    "when you are done. Use only the tools listed below."
)


@dataclass
class LoopResult:
    ok: bool
    final: Optional[dict]
    steps: int
    errors: list = field(default_factory=list)


def run_tool_loop(llm: LLM, system: str, task: str,
                  registry: ToolRegistry, *, max_steps: int = 6,
                  allow_write: bool = False,
                  log: Optional[RunLog] = None) -> LoopResult:
    full_system = f"{system}\n\n{PROTOCOL}\n\nTools:\n"
    full_system += registry.describe()
    transcript = f"Task: {task}"
    seen: dict[str, int] = {}
    for step in range(1, max_steps + 1):
        raw = llm.complete(full_system, transcript)
        try:
            msg = extract_json(raw)
        except ValueError as exc:
            transcript += f"\n\nObservation: invalid reply ({exc})."
            continue
        if msg.get("action") == "final":
            result = msg.get("result")
            if isinstance(result, dict):
                return LoopResult(True, result, step)
            transcript += "\n\nObservation: 'result' must be an object."
            continue
        name, args = msg.get("tool"), msg.get("args", {})
        key = json.dumps([name, args], sort_keys=True)
        seen[key] = seen.get(key, 0) + 1
        if seen[key] >= 3:
            return LoopResult(False, None, step,
                              ["same tool call repeated 3 times"])
        tool = registry.get(name) if isinstance(name, str) else None
        if tool is None:
            obs = f"unknown tool {name!r}"
        elif not tool.read_only and not allow_write:
            obs = f"tool {name!r} writes data and is not allowed"
        elif not isinstance(args, dict):
            obs = "args must be an object"
        else:
            try:
                obs = json.dumps(tool.func(**args), default=str)
            except Exception as exc:  # report, do not crash
                obs = f"tool error: {exc}"
        if log:
            log.event("tool", step=step, tool=name, args=args,
                      observation=obs[:500])
        transcript += f"\n\nObservation ({name}): {obs[:2000]}"
    return LoopResult(False, None, max_steps,
                      [f"no final answer after {max_steps} steps"])
