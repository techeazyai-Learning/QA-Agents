"""Score the checker on the golden set.

    python run_eval.py                      # stand-in model, offline
    python run_eval.py --provider openai --model <model-name>
"""
import argparse
import json
from dataclasses import asdict

from qa_agents.evaluate import evaluate
from qa_agents.fake_model import fake_bug_review
from qa_agents.llm import FunctionLLM, make_llm


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--provider", default="mock",
                    choices=["mock", "anthropic", "openai"])
    ap.add_argument("--model", default=None)
    ap.add_argument("--golden", default="golden/bug_reports.json")
    args = ap.parse_args(argv)
    if args.provider == "mock":
        llm = FunctionLLM(fake_bug_review)
    else:
        llm = make_llm(args.provider, args.model)
    print(json.dumps(asdict(evaluate(llm, args.golden)), indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
