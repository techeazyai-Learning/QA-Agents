"""Run the Part II agents on the sample data.

    python run_part2.py ch5            # stand-in model, offline
    python run_part2.py ch8 --provider anthropic --model <model-name>

Chapters: ch5 requirements, ch6 test cases, ch7 test data,
ch8 traceability, ch9 case review.
"""
import argparse
import json
import sys
from pathlib import Path

from qa_agents import fakes
from qa_agents.agents import (case_reviewer, requirement_reviewer, rtm,
                              test_case_generator, test_data)
from qa_agents.llm import FunctionLLM, make_llm
from qa_agents.runlog import RunLog

G = Path(__file__).parent / "golden"
FAKE = {"ch5": fakes.fake_requirement_review,
        "ch6": fakes.fake_generate_cases,
        "ch7": fakes.fake_test_data,
        "ch8": fakes.fake_rtm_links,
        "ch9": fakes.fake_case_review}


def load(name):
    return json.loads((G / name).read_text(encoding="utf-8"))


def ch5(llm, log):
    text = (G / "refund_story.txt").read_text(encoding="utf-8")
    res = requirement_reviewer.review_requirements(llm, text, log)
    if not res.ok:
        return {"ok": False, "errors": res.errors}
    score = requirement_reviewer.score_findings(
        res.findings, load("refund_seeded.json"))
    return {"ok": True, "findings": res.findings, "score": score}


def ch6(llm, log):
    spec = load("refund_rules.json")
    res = test_case_generator.generate_cases(
        llm, spec["feature"], spec["rules"], log)
    if not res.ok:
        return {"ok": False, "errors": res.errors}
    return {"ok": True, "cases": len(res.cases),
            "coverage": res.coverage,
            "input_gaps": res.gaps,
            "first_case": test_case_generator.to_gherkin(res.cases[0])}


def ch7(llm, log):
    fields = load("refund_fields.json")
    spec = load("refund_rules.json")
    plan = test_data.plan_test_data(
        llm, [{"id": "TC-001", "title": "Refund a delivered order"}],
        fields, log)
    if not plan.ok:
        return {"ok": False, "errors": plan.errors}
    data = test_data.synthesize(plan.recipes, fields, rows=3, seed=7,
                                overrides={"order_status": "delivered"})
    return {"ok": True, "needs": plan.needs, "data": data,
            "pii_risks": test_data.pii_risks(data),
            "rules_seen": len(spec["rules"])}


def ch8(llm, log):
    d = load("rtm.json")
    res = rtm.trace(llm, d["requirements"], d["tests"], log=log)
    if not res.ok:
        return {"ok": False, "errors": res.errors}
    return {"ok": True, "matrix": res.matrix,
            "score": rtm.score_links(res.links, d["golden_links"],
                                     res.candidates)}


def ch9(llm, log):
    d = load("sample_cases.json")
    res = case_reviewer.review_cases(llm, d["cases"], log)
    if not res.ok:
        return {"ok": False, "errors": res.errors}
    return {"ok": True, "lint": res.lint, "findings": res.findings}


RUN = {"ch5": ch5, "ch6": ch6, "ch7": ch7, "ch8": ch8, "ch9": ch9}


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("chapter", choices=sorted(RUN))
    ap.add_argument("--provider", default="mock",
                    choices=["mock", "anthropic", "openai"])
    ap.add_argument("--model", default=None)
    args = ap.parse_args(argv)
    if args.provider == "mock":
        llm = FunctionLLM(FAKE[args.chapter])
    else:
        llm = make_llm(args.provider, args.model)
    out = RUN[args.chapter](llm, RunLog("runs/part2.jsonl"))
    print(json.dumps(out, indent=2, ensure_ascii=False))
    return 0 if out.get("ok") else 1


if __name__ == "__main__":
    sys.exit(main())
