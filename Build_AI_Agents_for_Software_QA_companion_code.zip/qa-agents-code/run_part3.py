"""Run the Part III agents on the sample data.

    python run_part3.py ch10           # stand-in model, offline
    python run_part3.py ch15 --note "Form fields now stack"
    python run_part3.py ch12 --provider anthropic --model <name>

Chapters: ch10 exploratory, ch11 test impact, ch12 API drift,
ch13 payload check, ch14 accessibility, ch15 visual drift.
Chapter 15 needs Pillow (pip install pillow).
"""
import argparse
import json
import sys
from pathlib import Path

from qa_agents import fakes
from qa_agents.llm import FunctionLLM, make_llm
from qa_agents.runlog import RunLog

G = Path(__file__).parent / "golden"
FAKE = {"ch10": fakes.fake_debrief, "ch11": fakes.fake_impact,
        "ch12": fakes.fake_drift, "ch13": fakes.fake_payload_map,
        "ch14": fakes.fake_a11y, "ch15": fakes.fake_visual}


def load(name):
    return json.loads((G / name).read_text(encoding="utf-8"))


def ch10(llm, log, note=""):
    from qa_agents.agents import exploratory
    res = exploratory.debrief(
        llm, load("session_charter.json"),
        (G / "session_notes.txt").read_text(encoding="utf-8"), log)
    if not res.ok:
        return {"ok": False, "errors": res.errors}
    return {"ok": True, "stats": res.stats, "debrief": res.data,
            "untouched_areas": res.untouched_areas}


def ch11(llm, log, note=""):
    from qa_agents.agents import impact
    plan = load("impact_map.json")
    changed = impact.parse_changed(
        (G / "changed_files.txt").read_text(encoding="utf-8"))
    res = impact.analyze(llm, changed, plan, log)
    if not res.ok:
        return {"ok": False, "errors": res.errors}
    return {"ok": True, "selection": res.selection,
            "suggestions": res.suggestions,
            "safety": impact.safety_report(plan)}


def ch12(llm, log, note=""):
    from qa_agents.agents import contract_drift
    res = contract_drift.analyze(llm, load("api_v1.json"),
                                 load("api_v2.json"), log)
    if not res.ok:
        return {"ok": False, "errors": res.errors}
    return {"ok": True, "changes": res.changes, "items": res.items}


def ch13(llm, log, note=""):
    from qa_agents.agents import payload_check
    res = payload_check.validate(
        llm, load("order_api.json"), load("order_ui.json"),
        load("order_mapping.json"), log)
    if not res.ok:
        return {"ok": False, "errors": res.errors}
    return {"ok": True, "approved": res.approved,
            "proposed": res.proposed,
            "not_displayed": res.not_displayed}


def ch14(llm, log, note=""):
    from qa_agents.agents import a11y_triage
    res = a11y_triage.triage(llm, load("axe_results.json"), log)
    if not res.ok:
        return {"ok": False, "errors": res.errors}
    return {"ok": True, "groups": res.groups, "items": res.items,
            "manual_checks": res.manual_checks}


def ch15(llm, log, note=""):
    from qa_agents.agents import visual_drift
    v = G / "visual"
    res = visual_drift.review(
        llm, str(v / "baseline.png"), str(v / "current.png"),
        load("visual/baseline_boxes.json"),
        load("visual/current_boxes.json"), note, log)
    if not res.ok:
        return {"ok": False, "errors": res.errors}
    return {"ok": True, "gate": res.gate,
            "regions": [{k: r[k] for k in ("id", "x", "y", "w", "h")}
                        for r in res.regions],
            "findings": res.findings}


RUN = {"ch10": ch10, "ch11": ch11, "ch12": ch12, "ch13": ch13,
       "ch14": ch14, "ch15": ch15}


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("chapter", choices=sorted(RUN))
    ap.add_argument("--provider", default="mock",
                    choices=["mock", "anthropic", "openai"])
    ap.add_argument("--model", default=None)
    ap.add_argument("--note", default="")
    args = ap.parse_args(argv)
    if args.provider == "mock":
        llm = FunctionLLM(FAKE[args.chapter])
    else:
        llm = make_llm(args.provider, args.model)
    out = RUN[args.chapter](llm, RunLog("runs/part3.jsonl"),
                            args.note)
    print(json.dumps(out, indent=2, ensure_ascii=False))
    return 0 if out.get("ok") else 1


if __name__ == "__main__":
    sys.exit(main())
