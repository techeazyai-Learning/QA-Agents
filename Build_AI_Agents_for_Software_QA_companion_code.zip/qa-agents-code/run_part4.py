"""Run the Part IV agents on the sample data.

    python run_part4.py ch16           # stand-in model, offline
    python run_part4.py ch18 --provider anthropic --model <name>

Chapters: ch16 bug reports, ch17 log summary, ch18 regression
mapping, ch19 flaky triage.
"""
import argparse
import json
import sys
from pathlib import Path

from qa_agents import fakes
from qa_agents.agents import (bug_writer, flaky_triage, log_summarizer,
                              regression_map)
from qa_agents.llm import FunctionLLM, make_llm
from qa_agents.runlog import RunLog

G = Path(__file__).parent / "golden"
FAKE = {"ch16": fakes.fake_bug_writer, "ch17": fakes.fake_log,
        "ch18": fakes.fake_regression, "ch19": fakes.fake_flaky}


def load(name):
    return json.loads((G / name).read_text(encoding="utf-8"))


def ch16(llm, log):
    inbox = load("bug_inbox.json")
    found, drafts, expected = {}, {}, {}
    for new in inbox["new_reports"]:
        res = bug_writer.write_report(llm, new["raw"],
                                      inbox["existing"], log)
        if not res.ok:
            return {"ok": False, "report": new["id"],
                    "errors": res.errors}
        found[new["id"]] = bug_writer.duplicate_ids(res.checks)
        expected[new["id"]] = new["expected_duplicates"]
        drafts[new["id"]] = res.draft
    return {"ok": True, "duplicates": found,
            "score": bug_writer.score_duplicates(found, expected),
            "first_draft": bug_writer.to_markdown(drafts["NEW-1"])}


def ch17(llm, log):
    text = (G / "service.log").read_text(encoding="utf-8")
    res = log_summarizer.summarize(llm, text, log)
    if not res.ok:
        return {"ok": False, "errors": res.errors}
    return {"ok": True, "first_error_line":
            res.digest["first_error_line"],
            "anchor_line": res.digest["anchor_line"],
            "errors_per_minute": res.rate, "report": res.data}


def ch18(llm, log):
    bugs, tests = load("fixed_bugs.json"), load("test_catalog.json")
    res = regression_map.map_bugs(llm, bugs, tests, log)
    if not res.ok:
        return {"ok": False, "errors": res.errors}
    return {"ok": True, "items": res.items,
            "summary": regression_map.summary(res.items),
            "score": regression_map.score_outcomes(res.items, bugs),
            "backlog": regression_map.backlog_csv(res.items)}


def ch19(llm, log):
    records = load("test_runs.json")
    res = flaky_triage.triage(llm, records, log)
    if not res.ok:
        return {"ok": False, "errors": res.errors}
    return {"ok": True, "kinds": res.kinds, "actions": res.actions,
            "items": res.items}


RUN = {"ch16": ch16, "ch17": ch17, "ch18": ch18, "ch19": ch19}


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("chapter", choices=sorted(RUN))
    ap.add_argument("--provider", default="mock",
                    choices=["mock", "anthropic", "openai"])
    ap.add_argument("--model", default=None)
    args = ap.parse_args(argv)
    if args.provider == "mock":
        llm = FunctionLLM(FAKE[args.chapter])
    else:
        llm = make_llm(args.provider, args.model)
    out = RUN[args.chapter](llm, RunLog("runs/part4.jsonl"))
    print(json.dumps(out, indent=2, ensure_ascii=False))
    return 0 if out.get("ok") else 1


if __name__ == "__main__":
    sys.exit(main())
