"""Run the Part V agents on the sample data.

    python run_part5.py ch20           # stand-in model, offline
    python run_part5.py ch22 --provider anthropic --model <name>

Chapters: ch20 performance scenarios, ch21 security test ideas,
ch22 LLM output evaluation.
"""
import argparse
import json
import sys
from pathlib import Path

from qa_agents import fakes
from qa_agents.agents import llm_eval, perf_scenarios, security_ideas
from qa_agents.llm import FunctionLLM, make_llm
from qa_agents.runlog import RunLog

G = Path(__file__).parent / "golden"
FAKE = {"ch20": fakes.fake_perf, "ch21": fakes.fake_security,
        "ch22": fakes.fake_judge}


def load(name):
    return json.loads((G / name).read_text(encoding="utf-8"))


def ch20(llm, log):
    profile = load("traffic_profile.json")
    res = perf_scenarios.design(llm, profile, log)
    if not res.ok:
        return {"ok": False, "errors": res.errors}
    return {"ok": True,
            "plan": [{k: s[k] for k in ("id", "kind", "multiplier",
                                        "total_rps", "virtual_users")}
                     for s in res.plan],
            "notes": res.data,
            "k6_script_S3": perf_scenarios.k6_script(profile,
                                                     res.plan[2])}


def ch21(llm, log):
    spec = (G / "security_feature.txt").read_text(encoding="utf-8")
    rules = load("security_rules.json")
    res = security_ideas.design(llm, spec, rules, log)
    if not res.ok:
        return {"ok": False, "errors": res.errors}
    return {"ok": True, "banner": res.banner,
            "traits": [{k: t[k] for k in ("ref", "id", "category")}
                       for t in res.traits],
            "ideas_per_category": {
                k: len(v) for k, v in
                security_ideas.by_category(res).items()},
            "ideas": res.ideas}


def ch22(llm, log):
    data = load("llm_eval_cases.json")
    results = llm_eval.evaluate(llm, data, log)
    return {"ok": all(r.ok for r in results),
            "results": [{"id": r.id, "scores": r.scores,
                         "findings": [f["check"] for f in r.findings],
                         "verdict": r.verdict, "errors": r.errors}
                        for r in results],
            "vs_humans": llm_eval.compare_to_humans(
                results, data["cases"]),
            "stability": llm_eval.stability(llm, data)}


RUN = {"ch20": ch20, "ch21": ch21, "ch22": ch22}


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("chapter", choices=sorted(RUN))
    ap.add_argument("--provider", default="mock",
                    choices=["mock", "anthropic", "openai"])
    ap.add_argument("--model", default=None)
    args = ap.parse_args(argv)
    if args.provider == "mock":
        llm = FunctionLLM(FAKE[args.chapter])
    else:
        llm = make_llm(args.provider, args.model)
    out = RUN[args.chapter](llm, RunLog("runs/part5.jsonl"))
    print(json.dumps(out, indent=2, ensure_ascii=False))
    return 0 if out.get("ok") else 1


if __name__ == "__main__":
    sys.exit(main())
