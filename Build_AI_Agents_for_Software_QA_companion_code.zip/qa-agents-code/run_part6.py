"""Run the Part VI agents on the sample data.

    python run_part6.py ch23           # stand-in model, offline
    python run_part6.py ch24 --audience executive
    python run_part6.py ch23 --provider anthropic --model <name>

Chapters: ch23 release readiness scorecard, ch24 report narrator.
"""
import argparse
import json
import sys
from pathlib import Path

from qa_agents import fakes
from qa_agents.agents import release_readiness, report_narrator
from qa_agents.llm import FunctionLLM, make_llm
from qa_agents.runlog import RunLog

G = Path(__file__).parent / "golden"
FAKE = {"ch23": fakes.fake_readiness, "ch24": fakes.fake_narrator}


def load(name):
    return json.loads((G / name).read_text(encoding="utf-8"))


def ch23(llm, log, audience=None):
    res = release_readiness.scorecard(
        llm, load("release_evidence.json"),
        load("release_gates.json"), log)
    if not res.ok:
        return {"ok": False, "errors": res.errors}
    return {"ok": True, "overall": res.overall,
            "meaning": release_readiness.MEANING[res.overall],
            "counts": res.counts,
            "gates": [{k: r[k] for k in ("id", "status", "detail")}
                      for r in res.rows],
            "notes": res.notes}


def ch24(llm, log, audience="executive"):
    ev = load("release_evidence.json")
    rows = release_readiness.evaluate(ev, load("release_gates.json"))
    res = report_narrator.narrate(llm, audience, ev, rows, log)
    if not res.ok:
        return {"ok": False, "errors": res.errors}
    return {"ok": True, "audience": audience,
            "words": report_narrator.word_count(res.report),
            "text": report_narrator.to_text(res.report)}


RUN = {"ch23": ch23, "ch24": ch24}


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("chapter", choices=sorted(RUN))
    ap.add_argument("--provider", default="mock",
                    choices=["mock", "anthropic", "openai"])
    ap.add_argument("--model", default=None)
    ap.add_argument("--audience", default="executive",
                    choices=sorted(report_narrator.AUDIENCES))
    args = ap.parse_args(argv)
    if args.provider == "mock":
        llm = FunctionLLM(FAKE[args.chapter])
    else:
        llm = make_llm(args.provider, args.model)
    out = RUN[args.chapter](llm, RunLog("runs/part6.jsonl"),
                            args.audience)
    print(json.dumps(out, indent=2, ensure_ascii=False))
    return 0 if out.get("ok") else 1


if __name__ == "__main__":
    sys.exit(main())
