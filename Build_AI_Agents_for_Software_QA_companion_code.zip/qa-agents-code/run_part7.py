"""Run the Part VII material: orchestration, red team, measurement.

    python run_part7.py ch25                    # pipeline, stops at L2
    python run_part7.py ch25 --approve publish  # after a named approval
    python run_part7.py ch26                    # red-team table
    python run_part7.py ch27                    # review and time study
    python run_part7.py ch28 --spec golden/spec_changelog.json \\
        --out generated                         # scaffold agent 21
"""
import argparse
import json
import sys
from pathlib import Path

from qa_agents import fakes, measure, new_agent, redteam
from qa_agents.llm import FunctionLLM, make_llm
from qa_agents.release_day import build
from qa_agents.runlog import RunLog

G = Path(__file__).parent / "golden"


def load(name):
    return json.loads((G / name).read_text(encoding="utf-8"))


def ch25(args):
    llm = (FunctionLLM(fakes.fake_router) if args.provider == "mock"
           else make_llm(args.provider, args.model))
    pipe = build(load("test_runs.json"), load("release_evidence.json"),
                 load("release_gates.json"), Path(args.outbox))
    rep = pipe.run(llm, RunLog("runs/part7.jsonl"),
                   approved=set(args.approve), max_level=args.level,
                   total_calls=12)
    return {"ok": rep.ok, "complete": rep.complete, "calls": rep.calls,
            "steps": [dict(zip(("step", "level", "status", "calls",
                                "detail"), row))
                      for row in rep.table()]}


def ch26(args):
    rows = redteam.run_all()
    return {"ok": all(r["as_expected"] for r in rows),
            "stopped": sum(r["got"] == "stopped" for r in rows),
            "got_through": sum(r["got"] != "stopped" for r in rows),
            "attacks": rows}


def ch27(args):
    return {"ok": True,
            "reviews": measure.review_summary(load("review_log.json")),
            "time": measure.time_summary(load("time_study.json")),
            "note": "the datasets are invented for this book"}


def ch28(args):
    spec = json.loads(Path(args.spec).read_text(encoding="utf-8"))
    out = Path(args.out)
    (out / "agents").mkdir(parents=True, exist_ok=True)
    (out / "tests").mkdir(parents=True, exist_ok=True)
    made = new_agent.generate(spec, out / "agents", out / "tests")
    return {"ok": True, "wrote": [str(p) for p in made]}


RUN = {"ch25": ch25, "ch26": ch26, "ch27": ch27, "ch28": ch28}


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawTextHelpFormatter)
    ap.add_argument("chapter", choices=sorted(RUN))
    ap.add_argument("--provider", default="mock",
                    choices=["mock", "anthropic", "openai"])
    ap.add_argument("--model", default=None)
    ap.add_argument("--approve", action="append", default=[])
    ap.add_argument("--level", default="L2",
                    choices=["L0", "L1", "L2", "L3"])
    ap.add_argument("--outbox", default="runs/outbox")
    ap.add_argument("--spec", default="golden/spec_changelog.json")
    ap.add_argument("--out", default="generated")
    args = ap.parse_args(argv)
    out = RUN[args.chapter](args)
    print(json.dumps(out, indent=2, ensure_ascii=False))
    return 0 if out.get("ok") else 1


if __name__ == "__main__":
    sys.exit(main())
