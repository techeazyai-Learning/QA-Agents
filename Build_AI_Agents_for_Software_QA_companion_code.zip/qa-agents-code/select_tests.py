"""Pick tests for a change. No model involved.

    git diff --name-only origin/main...HEAD > changed.txt
    python select_tests.py changed.txt golden/impact_map.json

Prints one test ID per line. Exit code 0 if tests were selected,
3 if the plan says to run everything, 4 if nothing needs to run.
"""
import json
import sys

from qa_agents.agents.impact import parse_changed, select_tests


def main(argv=None) -> int:
    args = sys.argv[1:] if argv is None else argv
    if len(args) != 2:
        print(__doc__)
        return 2
    changed = parse_changed(open(args[0], encoding="utf-8").read())
    plan = json.load(open(args[1], encoding="utf-8"))
    sel = select_tests(changed, plan)
    for t in sel["tests"]:
        print(t)
    if sel["mode"] == "run_all":
        print(f"# run everything: {sel['trigger']}", file=sys.stderr)
        return 3
    for f in sel["unmapped"]:
        print(f"# no coverage data for {f}", file=sys.stderr)
    return 0 if sel["tests"] else 4


if __name__ == "__main__":
    sys.exit(main())
