import json
from pathlib import Path

from qa_agents import fakes
from qa_agents.agents import a11y_triage as at
from qa_agents.llm import FunctionLLM, MockLLM

G = Path(__file__).parent.parent / "golden"
AXE = json.loads((G / "axe_results.json").read_text("utf-8"))


def test_criteria_and_levels_from_tags():
    tags = ["cat.color", "wcag2aa", "wcag143", "wcag1411", "wcag22aa"]
    assert at.criteria(tags) == ["1.4.11", "1.4.3"]
    assert at.levels(tags) == ["wcag22aa", "wcag2aa"]
    assert at.criteria(["best-practice"]) == []


def test_groups_sorted_by_impact_then_count():
    g = at.summarize(AXE["violations"])
    assert [x["rule_id"] for x in g][:3] == [
        "button-name", "image-alt", "select-name"]
    impacts = [x["impact"] for x in g]
    assert impacts == sorted(impacts, key=at.IMPACT_ORDER.get)
    region = next(x for x in g if x["rule_id"] == "region")
    assert region["best_practice"] and region["wcag"] == []
    assert region["count"] == 6 and len(region["examples"]) == 3


def test_stand_in_report_has_manual_checklist():
    res = at.triage(FunctionLLM(fakes.fake_a11y), AXE)
    assert res.ok and len(res.items) == len(res.groups)
    assert len(res.manual_checks) >= 6


def test_compliance_claims_are_rejected():
    items = [{"rule_id": g["rule_id"], "who_is_affected": "x",
              "fix": "y", "test_to_add": "z"}
             for g in at.summarize(AXE["violations"])]
    items[0]["fix"] = "After this the page is fully accessible."
    bad = json.dumps({"items": items})
    llm = MockLLM([bad] * 3)
    res = at.triage(llm, AXE)
    assert not res.ok
    assert "forbidden claim" in llm.calls[1]["user"]


def test_missing_and_unknown_rules_are_rejected():
    bad = json.dumps({"items": [{
        "rule_id": "made-up", "who_is_affected": "x", "fix": "y",
        "test_to_add": "z"}]})
    llm = MockLLM([bad] * 3)
    at.triage(llm, AXE)
    assert "unknown rule_id 'made-up'" in llm.calls[1]["user"]
    assert "missing item for button-name" in llm.calls[1]["user"]


def test_clean_scan_still_returns_manual_checks_without_model():
    llm = MockLLM([])
    res = at.triage(llm, {"violations": []})
    assert res.ok and res.manual_checks and llm.calls == []
