import json
from pathlib import Path

from qa_agents import fakes
from qa_agents.agents import bug_writer as bw
from qa_agents.llm import FunctionLLM, MockLLM

G = Path(__file__).parent.parent / "golden"
INBOX = json.loads((G / "bug_inbox.json").read_text("utf-8"))
EXISTING = INBOX["existing"]
NEW = {n["id"]: n for n in INBOX["new_reports"]}


def draft(**over):
    d = {"title": "Second refund is accepted above the limit",
         "steps": ["Refunded 20.00 (ok), then refunded 120.00"],
         "expected": "Should have been blocked, only 100.00 left.",
         "actual": "The refund of 120.00 was accepted.",
         "environment": "Chrome 128", "missing_info": [],
         "severity": "major", "severity_reason": "Wrong money."}
    d.update(over)
    return d


def reply(d, checks=()):
    return json.dumps({"draft": d, "duplicate_checks": list(checks)})


def test_specifics_treat_equal_numbers_as_equal():
    assert bw.specifics("120.00 and 120, 1,249.50") == {"120", "1249.5"}
    assert "2026.10.3" in bw.specifics("build 2026.10.3")


def test_invented_numbers_are_found():
    src = NEW["NEW-1"]["raw"]
    assert bw.invented_specifics(draft(), src) == []
    bad = draft(environment="Chrome 129")
    assert bw.invented_specifics(bad, src) == [
        "the number '129' is not in the notes"]


def test_candidates_use_stems_and_keep_closed_bugs():
    assert bw.candidates(NEW["NEW-1"]["raw"], EXISTING) == ["BUG-101"]
    assert "BUG-103" in bw.candidates(NEW["NEW-4"]["raw"], EXISTING)
    assert bw.candidates("zebra giraffe", EXISTING) == []


def test_model_cannot_invent_a_version_or_skip_a_candidate():
    raw = NEW["NEW-1"]["raw"]
    bad = reply(draft(environment="Chrome 129, build 2026.10.9"))
    llm = MockLLM([bad] * 3)
    res = bw.write_report(llm, raw, EXISTING)
    assert not res.ok
    assert "is not in the notes" in llm.calls[1]["user"]
    assert "missing check for BUG-101" in llm.calls[1]["user"]


def test_unknown_duplicate_id_is_rejected():
    raw = NEW["NEW-1"]["raw"]
    bad = reply(draft(), [{"bug_id": "BUG-999", "verdict": "different",
                           "reason": "x"}])
    llm = MockLLM([bad] * 3)
    bw.write_report(llm, raw, EXISTING)
    assert "unknown bug_id 'BUG-999'" in llm.calls[1]["user"]


def test_ungrounded_step_is_rejected():
    raw = NEW["NEW-1"]["raw"]
    chk = [{"bug_id": "BUG-101", "verdict": "duplicate", "reason": "x"}]
    bad = reply(draft(steps=["Log in as an administrator and wait"]),
                chk)
    llm = MockLLM([bad] * 3)
    bw.write_report(llm, raw, EXISTING)
    assert "step not grounded" in llm.calls[1]["user"]


def test_stand_in_end_to_end_and_scoring():
    llm = FunctionLLM(fakes.fake_bug_writer)
    found, want = {}, {}
    for n in INBOX["new_reports"]:
        res = bw.write_report(llm, n["raw"], EXISTING)
        assert res.ok
        found[n["id"]] = bw.duplicate_ids(res.checks)
        want[n["id"]] = n["expected_duplicates"]
    s = bw.score_duplicates(found, want)
    assert s["false_positives"] == 0 and s["missed"] == 1
    assert s["recall"] == 0.667


def test_score_and_markdown():
    s = bw.score_duplicates({"a": ["X", "Y"]}, {"a": ["X"], "b": ["Z"]})
    assert s == {"precision": 0.5, "recall": 0.5,
                 "false_positives": 1, "missed": 1}
    md = bw.to_markdown(draft(missing_info=["Screenshot?"]))
    assert md.startswith("# Second refund") and "- Screenshot?" in md
