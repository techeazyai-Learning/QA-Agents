import json
from pathlib import Path

from qa_agents import fakes
from qa_agents.agents import case_reviewer as cr
from qa_agents.llm import FunctionLLM, MockLLM

D = json.loads((Path(__file__).parent.parent / "golden"
                / "sample_cases.json").read_text("utf-8"))
CASES = D["cases"]


def rules(issues):
    return {(i["case_id"], i["rule"]) for i in issues}


def test_lint_catches_structural_problems():
    got = rules(cr.lint_cases(CASES))
    assert ("C6", "no_expected") in got
    assert ("C8", "too_many_steps") in got
    assert ("C5", "vague_step") in got
    assert ("C2", "near_duplicate") in got


def test_lint_flags_missing_negative_coverage():
    got = rules(cr.lint_cases(CASES))
    assert ("(suite)", "no_negative_case") in got
    neg = [{**CASES[0], "id": "N1", "type": "negative",
            "title": "x unique", "steps": ["other thing entirely"]}]
    assert ("(suite)", "no_negative_case") not in rules(
        cr.lint_cases(neg))


def test_lint_duplicate_title_and_empty_case():
    cases = [{"id": "A", "title": "Same", "steps": ["one"],
              "expected": ["x"]},
             {"id": "B", "title": "same", "steps": [], "expected": []}]
    got = rules(cr.lint_cases(cases))
    assert ("A", "duplicate_title") in got
    assert ("B", "no_steps") in got and ("B", "no_expected") in got


def test_lint_is_clean_on_a_good_suite():
    good = [{"id": "G1", "title": "Reject empty reason", "type":
             "negative", "rule_ids": ["R2"],
             "steps": ["Leave reason empty", "Submit"],
             "expected": ["Error: reason is required"]}]
    assert cr.lint_cases(good) == []


def test_review_with_stand_in_flags_seeded_problems():
    res = cr.review_cases(FunctionLLM(fakes.fake_case_review), CASES)
    assert res.ok
    got = {(f["case_id"], f["category"]) for f in res.findings}
    assert ("C3", "multiple_behaviours") in got
    assert ("C4", "weak_expected") in got
    assert ("C7", "hidden_dependency") in got


def test_made_up_quote_is_rejected():
    bad = json.dumps({"findings": [{
        "case_id": "C1", "category": "weak_expected",
        "quote": "not in the case", "issue": "x", "fix": "y"}]})
    res = cr.review_cases(MockLLM([bad] * 3), CASES)
    assert not res.ok and res.lint
