import copy
import json
from pathlib import Path

from qa_agents import fakes
from qa_agents.agents import contract_drift as cd
from qa_agents.llm import FunctionLLM, MockLLM

G = Path(__file__).parent.parent / "golden"
V1 = json.loads((G / "api_v1.json").read_text("utf-8"))
V2 = json.loads((G / "api_v2.json").read_text("utf-8"))


def kinds(changes, sev=None):
    return {(c["kind"], c["severity"]) for c in changes
            if sev in (None, c["severity"])}


def test_identical_specs_have_no_changes():
    assert cd.diff_specs(V1, copy.deepcopy(V1)) == []


def test_sample_diff_finds_every_planted_change():
    ch = cd.diff_specs(V1, V2)
    assert len(ch) == 10
    assert sum(c["severity"] == "breaking" for c in ch) == 5
    assert ("field_removed", "breaking") in kinds(ch)
    assert ("type_changed", "breaking") in kinds(ch)
    assert ("enum_value_removed", "breaking") in kinds(ch)
    assert ("enum_value_added", "risky") in kinds(ch)
    assert ("endpoint_added", "safe") in kinds(ch)
    assert [c["severity"] for c in ch] == sorted(
        (c["severity"] for c in ch),
        key=lambda s: cd.SEVERITY_ORDER[s])


def test_removed_endpoint_is_breaking():
    new = copy.deepcopy(V1)
    del new["paths"]["/refunds/{refundId}"]
    ch = cd.diff_specs(V1, new)
    assert kinds(ch) == {("endpoint_removed", "breaking")}


def test_response_enum_value_removed_is_safe_request_is_breaking():
    new = copy.deepcopy(V1)
    new["components"]["schemas"]["Order"]["properties"]["status"][
        "enum"].remove("pending")
    assert kinds(cd.diff_specs(V1, new)) == {
        ("enum_value_removed", "safe")}


def test_optional_param_added_is_safe_required_is_breaking():
    new = copy.deepcopy(V1)
    op = new["paths"]["/refunds/{refundId}"]["get"]
    op["parameters"].append({"name": "v", "in": "query",
                             "required": False,
                             "schema": {"type": "string"}})
    assert kinds(cd.diff_specs(V1, new)) == {("param_added", "safe")}
    op["parameters"][-1]["required"] = True
    assert kinds(cd.diff_specs(V1, new)) == {
        ("param_added", "breaking")}


def test_ref_cycles_do_not_hang():
    spec = {"paths": {"/a": {"get": {"responses": {"200": {
        "content": {"application/json": {"schema": {
            "$ref": "#/components/schemas/Node"}}}}}}}},
        "components": {"schemas": {"Node": {
            "type": "object", "properties": {
                "next": {"$ref": "#/components/schemas/Node"}}}}}}
    assert cd.diff_specs(spec, spec) == []
    assert cd.resolve({"a": {"$ref": "#/a"}}, {"$ref": "#/a"}) == {}


def test_model_must_cover_every_breaking_and_risky_change():
    ch = cd.diff_specs(V1, V2)
    partial = json.dumps({"items": [{
        "change_id": "C1", "client_impact": "x",
        "test_ideas": ["t"]}]})
    llm = MockLLM([partial] * 3)
    res = cd.analyze(llm, V1, V2)
    assert not res.ok and "missing item for C2" in llm.calls[1]["user"]
    assert len(res.changes) == len(ch)


def test_model_cannot_comment_on_safe_changes_or_invent_ids():
    bad = json.dumps({"items": [
        {"change_id": "C7", "client_impact": "x", "test_ideas": ["t"]},
        {"change_id": "C99", "client_impact": "x",
         "test_ideas": ["t"]}]})
    llm = MockLLM([bad] * 3)
    cd.analyze(llm, V1, V2)
    assert "C7 is safe" in llm.calls[1]["user"]
    assert "unknown change_id 'C99'" in llm.calls[1]["user"]


def test_stand_in_end_to_end_and_no_model_call_when_all_safe():
    res = cd.analyze(FunctionLLM(fakes.fake_drift), V1, V2)
    assert res.ok and len(res.items) == 6
    new = copy.deepcopy(V1)
    new["paths"]["/new"] = {"get": {"responses": {}}}
    llm = MockLLM([])
    assert cd.analyze(llm, V1, new).ok and llm.calls == []
