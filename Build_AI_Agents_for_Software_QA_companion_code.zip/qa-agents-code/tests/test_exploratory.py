import json
from pathlib import Path

from qa_agents import fakes
from qa_agents.agents import exploratory as ex
from qa_agents.llm import FunctionLLM, MockLLM

G = Path(__file__).parent.parent / "golden"
CHARTER = json.loads((G / "session_charter.json").read_text("utf-8"))
NOTES = (G / "session_notes.txt").read_text("utf-8")


def test_parse_notes_tags_times_and_ids():
    e = ex.parse_notes("00:03 NOTE opened\n01:05 BUG broke it\n"
                       "junk line\n01:07 plain text\n")
    assert [x["id"] for x in e] == ["N1", "N2", "N3"]
    assert e[1]["minute"] == 65 and e[1]["tag"] == "BUG"
    assert e[2]["tag"] == "NOTE" and e[2]["text"] == "plain text"


def test_stats_are_exact_and_find_long_gaps():
    e = ex.parse_notes(NOTES)
    s = ex.session_stats(e, 60)
    assert s["counts"]["BUG"] == 2 and s["counts"]["Q"] == 2
    assert s["elapsed_minutes"] == 49 and not s["over_time"]
    assert s["long_gaps"] == [("N7", "N8", 14)]
    assert ex.session_stats(e, 30)["over_time"]


def test_empty_notes_do_not_crash():
    assert ex.session_stats([], 30)["elapsed_minutes"] == 0


def test_debrief_with_stand_in_and_untouched_areas():
    res = ex.debrief(FunctionLLM(fakes.fake_debrief), CHARTER, NOTES)
    assert res.ok
    assert len(res.data["bugs_to_report"]) == 2
    assert "concurrency" in res.untouched_areas
    assert "audit log" not in res.untouched_areas


def test_invented_quote_is_rejected_and_repaired():
    bad = {"summary": "s", "areas_touched": [], "open_questions": [],
           "follow_up_charters": [],
           "bugs_to_report": [{"note_id": "N1", "quote": "not there",
                               "text": "x"}]}
    good = {**bad, "bugs_to_report": []}
    llm = MockLLM([json.dumps(bad), json.dumps(good)])
    res = ex.debrief(llm, CHARTER, NOTES)
    assert res.ok and len(llm.calls) == 2
    assert "not in N1" in llm.calls[1]["user"]


def test_unknown_note_id_is_rejected():
    bad = {"summary": "s", "areas_touched": [], "bugs_to_report": [],
           "follow_up_charters": [], "open_questions": [
               {"note_id": "N99", "quote": "q", "text": "x"}]}
    res = ex.debrief(MockLLM([json.dumps(bad)] * 3), CHARTER, NOTES)
    assert not res.ok and res.stats["counts"]["BUG"] == 2
