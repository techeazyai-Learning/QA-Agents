import json
from pathlib import Path

from qa_agents import fakes
from qa_agents.agents import flaky_triage as ft
from qa_agents.llm import FunctionLLM, MockLLM

RUNS = json.loads((Path(__file__).parent.parent / "golden"
                   / "test_runs.json").read_text("utf-8"))
STATS = ft.run_stats(RUNS)


def test_counts_are_exact():
    s = STATS["test_refund_email_sent"]
    assert s["runs"] == 40 and s["fails"] == 7
    assert s["fail_rate"] == 0.175
    assert s["by"]["runner"]["ci-3"] == {"runs": 13, "fails": 7,
                                         "rate": 0.538}


def test_classification_separates_flaky_from_broken():
    kinds = {t: ft.classify(s) for t, s in STATS.items()}
    assert kinds["test_login"] == "stable"
    assert kinds["test_refund_amount_limits"] == "broken"
    assert STATS["test_refund_amount_limits"]["broken_since"] == "c7"
    assert kinds["test_refund_email_sent"] == "flaky"
    assert kinds["test_search_orders"] == "flaky"


def test_a_test_that_always_fails_is_not_broken_since_anything():
    rows = [{"run": i, "commit": f"c{i}", "runner": "r",
             "prev_test": "-", "test": "t", "outcome": "fail",
             "error": "boom", "ms": 1} for i in range(5)]
    s = ft.run_stats(rows)["t"]
    assert s["broken_since"] is None
    assert ft.classify(s) == "failing"


def test_policy_text_follows_rules():
    k = lambda t: ft.policy(STATS[t], ft.classify(STATS[t]))  # noqa
    assert k("test_refund_amount_limits").startswith("fix now")
    assert "quarantine" in k("test_refund_email_sent")
    assert k("test_search_orders").startswith("watch")
    assert k("test_login") == "none"


def test_supports_checks_the_statistics():
    email = STATS["test_refund_email_sent"]
    assert ft.supports("environment", email)
    assert not ft.supports("shared_state", email)
    happy = STATS["test_refund_service_happy"]
    assert ft.supports("shared_state", happy)
    assert not ft.supports("environment", happy)
    assert ft.supports("timing", email)


def reply(test, cat, quote):
    return json.dumps({"items": [{
        "test": test, "category": cat, "evidence_quote": quote,
        "reasoning": "r", "experiment": "e"}]})


def test_unsupported_category_and_bad_quote_are_rejected():
    llm = MockLLM([reply("test_refund_email_sent", "shared_state",
                         "TimeoutError")] * 3)
    res = ft.triage(llm, RUNS)
    assert not res.ok
    assert "do not support shared_state" in llm.calls[1]["user"]
    assert "missing item for test_refund_service_happy" in \
        llm.calls[1]["user"]
    llm2 = MockLLM([reply("test_refund_email_sent", "environment",
                          "disk full")] * 3)
    ft.triage(llm2, RUNS)
    assert "quote is not in an error" in llm2.calls[1]["user"]


def test_model_cannot_diagnose_a_broken_test_as_flaky():
    llm = MockLLM([reply("test_refund_amount_limits", "timing",
                         "x")] * 3)
    ft.triage(llm, RUNS)
    assert "unknown or non-flaky test" in llm.calls[1]["user"]


def test_stand_in_end_to_end_and_no_model_call_without_flaky():
    res = ft.triage(FunctionLLM(fakes.fake_flaky), RUNS)
    assert res.ok
    cats = {i["test"]: i["category"] for i in res.items}
    assert cats == {"test_refund_service_happy": "shared_state",
                    "test_refund_email_sent": "environment",
                    "test_search_orders": "external_dependency"}
    llm = MockLLM([])
    stable = [r for r in RUNS if r["test"] == "test_login"]
    assert ft.triage(llm, stable).ok and llm.calls == []
