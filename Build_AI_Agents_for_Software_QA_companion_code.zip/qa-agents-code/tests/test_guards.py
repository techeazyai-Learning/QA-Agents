from qa_agents.guards import (check_known_ids, check_quotes, duplicates,
                              jaccard, norm, quote_in, tokens)


def test_norm_and_quote_in_ignore_case_and_spacing():
    assert norm("  Hello   World ") == "hello world"
    assert quote_in("The  System SHALL respond", "system shall")
    assert not quote_in("The system", "")
    assert not quote_in("The system", "missing words")


def test_check_quotes_flags_unknown_id_and_false_quote():
    src = {"S1": "Users may log in."}
    ok = [{"statement_id": "S1", "quote": "may log in"}]
    assert check_quotes(ok, src) == []
    bad_id = [{"statement_id": "S9", "quote": "x"}]
    assert "unknown" in check_quotes(bad_id, src)[0]
    bad_q = [{"statement_id": "S1", "quote": "must log in"}]
    assert "not in S1" in check_quotes(bad_q, src)[0]


def test_known_ids_and_duplicates():
    assert check_known_ids(["R1", "R7"], ["R1"], "rule") == [
        "rule 'R7' does not exist"]
    assert duplicates(["A b", "a  B", "c"]) == ["a  B"]


def test_tokens_drop_filler_and_jaccard_bounds():
    assert tokens("The cat is on the mat") == {"cat", "mat"}
    assert jaccard({"a"}, {"a"}) == 1.0
    assert jaccard({"a"}, {"b"}) == 0.0
    assert jaccard(set(), {"b"}) == 0.0
