import json
from pathlib import Path

from qa_agents import fakes
from qa_agents.agents import impact as im
from qa_agents.llm import FunctionLLM, MockLLM

G = Path(__file__).parent.parent / "golden"
PLAN = json.loads((G / "impact_map.json").read_text("utf-8"))


def test_selection_uses_coverage_data_only():
    s = im.select_tests(["src/notify/email.py"], PLAN)
    assert s["mode"] == "selected"
    assert s["tests"] == ["test_refund_email_sent"]
    assert s["unmapped"] == []


def test_docs_are_ignored_and_unknown_files_are_unmapped():
    s = im.select_tests(["README.md", "src/new/thing.py"], PLAN)
    assert s["ignored"] == ["README.md"]
    assert s["unmapped"] == ["src/new/thing.py"] and s["tests"] == []


def test_config_change_runs_everything():
    s = im.select_tests(["src/x.py", "ci/pipeline.yml"], PLAN)
    assert s["mode"] == "run_all" and s["trigger"] == "ci/pipeline.yml"
    assert s["tests"] == sorted(PLAN["coverage"])


def test_exact_file_trigger_and_no_false_prefix_match():
    assert im.select_tests(["requirements.txt"], PLAN)["mode"] == \
        "run_all"
    assert im.select_tests(["ci_notes.py"], PLAN)["mode"] == "selected"


def test_parse_changed_ignores_blank_lines():
    assert im.parse_changed("a.py\n\n b.py \n") == ["a.py", "b.py"]


def test_safety_report_exposes_new_file_blind_spot():
    r = im.safety_report(PLAN)
    assert r["failures_total"] == 7 and r["failures_caught"] == 6
    missed = [row for row in r["rows"] if row["missed"]]
    assert missed[0]["changed"] == ["src/refunds/currency.py"]


def test_model_not_called_when_everything_is_mapped():
    llm = MockLLM([])
    res = im.analyze(llm, ["src/notify/email.py"], PLAN)
    assert res.ok and llm.calls == []


def test_suggestions_must_name_real_tests_and_files():
    changed = ["src/refunds/currency.py"]
    bad = json.dumps({"suggestions": [{
        "file": "src/refunds/currency.py", "test_ids": ["test_nope"],
        "new_test_idea": "x", "reason": "y"}]})
    res = im.analyze(MockLLM([bad] * 3), changed, PLAN)
    assert not res.ok and res.selection["unmapped"] == changed
    other = json.dumps({"suggestions": [{
        "file": "src/other.py", "test_ids": [],
        "new_test_idea": "x", "reason": "y"}]})
    res2 = im.analyze(MockLLM([other] * 3), changed, PLAN)
    assert not res2.ok


def test_stand_in_end_to_end():
    res = im.analyze(FunctionLLM(fakes.fake_impact),
                     ["src/refunds/currency.py"], PLAN)
    assert res.ok and res.suggestions[0]["test_ids"]


def test_always_run_list_is_passed_through():
    s = im.select_tests(["src/notify/email.py"], PLAN)
    assert s["always_run"] == ["tests/smoke/"]


def test_unmapped_policy_run_all_closes_the_blind_spot():
    strict = {**PLAN, "unmapped_policy": "run_all"}
    s = im.select_tests(["src/refunds/currency.py"], strict)
    assert s["mode"] == "run_all" and len(s["tests"]) == 8
    r = im.safety_report(strict)
    assert r["safety"] == 1.0
    assert r["avg_share_run"] > im.safety_report(PLAN)["avg_share_run"]


def test_select_tests_cli(tmp_path, capsys):
    import select_tests as cli
    f = tmp_path / "changed.txt"
    f.write_text("src/notify/email.py\n")
    plan = G / "impact_map.json"
    assert cli.main([str(f), str(plan)]) == 0
    assert capsys.readouterr().out.split() == ["test_refund_email_sent"]
    f.write_text("README.md\n")
    assert cli.main([str(f), str(plan)]) == 4
    f.write_text("ci/x.yml\n")
    assert cli.main([str(f), str(plan)]) == 3
