import pytest

from qa_agents.llm import (AnthropicLLM, FunctionLLM, MockLLM,
                           OpenAILLM, make_llm)


class _Obj:
    def __init__(self, **kw):
        self.__dict__.update(kw)


class FakeAnthropic:
    def __init__(self):
        self.seen = {}
        self.messages = _Obj(create=self._create)

    def _create(self, **kw):
        self.seen = kw
        return _Obj(content=[_Obj(type="text", text="hel"),
                             _Obj(type="tool_use"),
                             _Obj(type="text", text="lo")])


class FakeOpenAI:
    def __init__(self):
        self.seen = {}
        self.chat = _Obj(completions=_Obj(create=self._create))

    def _create(self, **kw):
        self.seen = kw
        msg = _Obj(content="hi there")
        return _Obj(choices=[_Obj(message=msg)])


def test_mock_llm_returns_in_order_and_records_calls():
    llm = MockLLM(["one", lambda s, u: f"echo:{u}"])
    assert llm.complete("s", "u1") == "one"
    assert llm.complete("s", "u2") == "echo:u2"
    assert len(llm.calls) == 2
    with pytest.raises(RuntimeError):
        llm.complete("s", "u3")


def test_function_llm():
    llm = FunctionLLM(lambda s, u: u.upper())
    assert llm.complete("s", "abc") == "ABC"


def test_anthropic_adapter_builds_request_and_joins_text():
    fake = FakeAnthropic()
    llm = AnthropicLLM(model="m", client=fake)
    assert llm.complete("sys", "usr", max_tokens=50) == "hello"
    assert fake.seen["model"] == "m"
    assert fake.seen["system"] == "sys"
    assert fake.seen["max_tokens"] == 50
    assert fake.seen["messages"] == [{"role": "user",
                                      "content": "usr"}]


def test_openai_adapter_builds_request_and_reads_choice():
    fake = FakeOpenAI()
    llm = OpenAILLM(model="m", client=fake)
    assert llm.complete("sys", "usr", max_tokens=7) == "hi there"
    assert fake.seen["max_completion_tokens"] == 7
    assert fake.seen["messages"][0] == {"role": "system",
                                        "content": "sys"}


def test_model_name_is_required(monkeypatch):
    monkeypatch.delenv("QA_AGENT_MODEL", raising=False)
    with pytest.raises(ValueError):
        AnthropicLLM(client=object())
    monkeypatch.setenv("QA_AGENT_MODEL", "from-env")
    assert OpenAILLM(client=object()).model == "from-env"


def test_unknown_provider():
    with pytest.raises(ValueError):
        make_llm("nope")
