import json
from pathlib import Path

from qa_agents import fakes
from qa_agents.agents import llm_eval as ev
from qa_agents.llm import FunctionLLM, MockLLM

DATA = json.loads((Path(__file__).parent.parent / "golden"
                   / "llm_eval_cases.json").read_text("utf-8"))
SRC = DATA["sources"]
CASES = {c["id"]: c for c in DATA["cases"]}


def checks(cid):
    return [f["check"] for f in ev.code_findings(CASES[cid], SRC)]


def test_good_answers_have_no_findings():
    for cid in ("E1", "E3", "E5", "E6"):
        assert checks(cid) == [], cid


def test_a_number_from_the_question_is_not_ungrounded():
    assert checks("E6") == []
    case = dict(CASES["E6"], question="Will I get my money soon?")
    got = [f["detail"] for f in ev.code_findings(case, SRC)]
    assert got == ["2 is not in the cited source"]


def test_wrong_number_is_found_by_code():
    f = ev.code_findings(CASES["E2"], SRC)
    assert [x["check"] for x in f] == ["ungrounded_number"]
    assert "45" in f[0]["detail"]


def test_promise_without_source_has_three_findings():
    assert checks("E4") == ["no_citation", "ungrounded_number",
                            "forbidden_phrase"]


def test_unknown_citation_and_length():
    case = {"id": "x", "question": "q", "answer": "Word " * 90
            + "[S9]"}
    got = [f["check"] for f in ev.code_findings(case, SRC)]
    assert "unknown_citation" in got and "too_long" in got


def reply(faith=5, comp=5, ev_faith="within 30 days", ev_comp=None):
    return json.dumps({"scores": [
        {"criterion": "faithfulness", "score": faith,
         "evidence": ev_faith, "reason": "r"},
        {"criterion": "completeness", "score": comp,
         "evidence": ev_comp or "within 30 days", "reason": "r"}]})


def test_valid_judgement_is_accepted():
    r = ev.evaluate_case(MockLLM([reply()]), CASES["E1"], SRC)
    assert r.ok and r.scores == {"faithfulness": 5, "completeness": 5}
    assert r.verdict == "pass"


def test_evidence_must_be_in_the_answer():
    llm = MockLLM([reply(ev_faith="within 90 days")] * 3)
    r = ev.evaluate_case(llm, CASES["E1"], SRC)
    assert not r.ok
    assert "evidence is not in the answer" in llm.calls[1]["user"]


def test_judge_may_not_contradict_the_code():
    llm = MockLLM([reply(faith=5, ev_faith="within 45 days",
                         ev_comp="within 45 days")] * 3)
    r = ev.evaluate_case(llm, CASES["E2"], SRC)
    assert not r.ok
    assert "faithfulness cannot be 4 or 5" in llm.calls[1]["user"]
    low = reply(faith=2, ev_faith="within 45 days",
                ev_comp="within 45 days")
    r = ev.evaluate_case(MockLLM([low]), CASES["E2"], SRC)
    assert r.ok and r.verdict == "fail"


def test_both_criteria_exactly_once():
    one = json.dumps({"scores": [
        {"criterion": "faithfulness", "score": 5,
         "evidence": "within 30 days", "reason": "r"}] * 2})
    llm = MockLLM([one] * 3)
    ev.evaluate_case(llm, CASES["E1"], SRC)
    assert "criterion completeness must appear exactly once" in \
        llm.calls[1]["user"]


def test_verdict_needs_no_findings_and_good_scores():
    ok = {"faithfulness": 5, "completeness": 5}
    assert ev.verdict([], ok) == "pass"
    assert ev.verdict([{"check": "no_citation", "detail": ""}],
                      ok) == "fail"
    assert ev.verdict([], {"faithfulness": 3,
                           "completeness": 5}) == "fail"


def test_stand_in_against_humans_finds_the_false_pass():
    results = ev.evaluate(FunctionLLM(fakes.fake_judge), DATA)
    assert all(r.ok for r in results)
    got = {r.id: r.verdict for r in results}
    assert got == {"E1": "pass", "E2": "fail", "E3": "pass",
                   "E4": "fail", "E5": "pass", "E6": "fail"}
    rep = ev.compare_to_humans(results, DATA["cases"])
    assert rep["false_passes"] == 1 and rep["false_fails"] == 1
    assert rep["big_misses"] == [
        {"case": "E5", "criterion": "completeness",
         "judge": 4, "human": 1},
        {"case": "E6", "criterion": "completeness",
         "judge": 2, "human": 5}]
    assert rep["within_one"]["faithfulness"] == 1.0


def test_stability_detects_a_judge_that_changes_its_mind():
    steady = FunctionLLM(fakes.fake_judge)
    assert ev.stability(steady, DATA) == 1.0
    flip = MockLLM([reply(5, 5), reply(4, 5)] * 20)
    assert ev.stability(flip, {"sources": SRC,
                               "cases": [CASES["E1"]]}) == 0.0
