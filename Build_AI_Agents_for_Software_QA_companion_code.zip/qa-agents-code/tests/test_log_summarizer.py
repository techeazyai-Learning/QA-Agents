import json
from pathlib import Path

from qa_agents import fakes
from qa_agents.agents import log_summarizer as ls
from qa_agents.llm import FunctionLLM, MockLLM

TEXT = (Path(__file__).parent.parent / "golden"
        / "service.log").read_text("utf-8")


def test_parse_keeps_line_numbers_and_attaches_traces():
    e = ls.parse_log(TEXT)
    assert len(e) == 32 and e[0]["line"] == 1
    boom = next(x for x in e if x["line"] == 15)
    assert [n for n, _ in boom["trace"]] == [16, 17, 18, 19]
    assert boom["req"] == "e6f1" and boom["level"] == "ERROR"


def test_signature_collapses_numbers_and_ids():
    a = ls.signature("refund failed order=1071 status=500")
    b = ls.signature("refund failed order=1099 status=500")
    assert a == b == "refund failed order=<N> status=<N>"


def test_clusters_sorted_by_level_then_count():
    g = ls.clusters(ls.parse_log(TEXT))
    assert [x["level"] for x in g] == sorted(
        (x["level"] for x in g), key=ls.LEVEL_ORDER.get)
    assert g[0]["count"] == 5 and g[0]["id"] == "K1"


def test_anchor_is_the_incident_not_the_first_error():
    d = ls.build_digest(ls.parse_log(TEXT))
    assert d["first_error_line"] == 6 and d["anchor_line"] == 15
    assert 15 in d["lines"] and 16 in d["lines"]


def test_digest_is_small_and_redacted():
    d = ls.build_digest(ls.parse_log(TEXT))
    assert len(d["lines"]) < 25
    blob = json.dumps(d)
    assert "asha.ardent@example.test" not in blob
    assert "abcdef0123456789abcdef0123456789" not in blob
    assert "[REDACTED_EMAIL]" in blob


def test_error_rate_by_minute():
    r = ls.error_rate_by_minute(ls.parse_log(TEXT))
    assert r == {"2026-10-24T10:15": 1, "2026-10-24T10:16": 2,
                 "2026-10-24T10:17": 8}


def hyp(evidence, confidence="medium"):
    return json.dumps({"summary": "s", "likely_unrelated": [],
                       "hypotheses": [{"cause": "c",
                                       "evidence": evidence,
                                       "confidence": confidence,
                                       "next_check": "n"}]})


def test_evidence_must_exist_and_quote_truthfully():
    bad_line = hyp([{"line": 999, "quote": "pool"}])
    llm = MockLLM([bad_line] * 3)
    res = ls.summarize(llm, TEXT)
    assert not res.ok and "line 999 is not in the digest" in \
        llm.calls[1]["user"]
    bad_quote = hyp([{"line": 9, "quote": "disk full"}])
    llm2 = MockLLM([bad_quote] * 3)
    ls.summarize(llm2, TEXT)
    assert "quote is not in line 9" in llm2.calls[1]["user"]


def test_high_confidence_needs_two_lines():
    one = hyp([{"line": 9, "quote": "pool"}], "high")
    llm = MockLLM([one] * 3)
    ls.summarize(llm, TEXT)
    assert "high confidence needs two cited lines" in \
        llm.calls[1]["user"]


def test_stand_in_end_to_end_and_no_error_log_skips_model():
    res = ls.summarize(FunctionLLM(fakes.fake_log), TEXT)
    assert res.ok and res.data["hypotheses"][0]["confidence"] == "high"
    assert res.data["likely_unrelated"] == ["K3", "K5"]
    llm = MockLLM([])
    quiet = "2026-10-24T10:00:00Z INFO svc req=1 msg=\"ok\"\n"
    assert ls.summarize(llm, quiet).ok and llm.calls == []
