import json
from pathlib import Path

import pytest

from qa_agents import measure as m

G = Path(__file__).parent.parent / "golden"
REVIEWS = json.loads((G / "review_log.json").read_text("utf-8"))
PAIRS = json.loads((G / "time_study.json").read_text("utf-8"))


def test_wilson_matches_hand_calculated_values():
    # 0 of 10: lower bound 0, upper bound 0.2775 (rounded 0.278)
    assert m.wilson(0, 10) == (0.0, 0.278)
    # 8 of 10: about 0.490 to 0.943
    assert m.wilson(8, 10) == (0.49, 0.943)
    assert m.wilson(50, 100) == (0.404, 0.596)
    assert m.wilson(0, 0) == (0.0, 1.0)


def test_wilson_interval_narrows_with_more_data():
    lo1, hi1 = m.wilson(6, 10)
    lo2, hi2 = m.wilson(600, 1000)
    assert hi2 - lo2 < (hi1 - lo1) / 5
    assert lo2 < 0.6 < hi2


def test_review_summary_counts_and_rates():
    s = m.review_summary(REVIEWS)
    bw = s["bug_writer"]
    assert bw["n"] == 40
    assert bw["counts"] == {"accepted": 24, "edited": 11,
                            "rejected": 5}
    assert bw["accepted"]["rate"] == 0.6
    assert bw["useful"]["rate"] == 0.875
    assert bw["accepted"]["low"] < 0.6 < bw["accepted"]["high"]


def test_small_samples_are_flagged():
    s = m.review_summary(REVIEWS)
    assert s["bug_writer"]["note"] == ""
    assert s["log_summarizer"]["note"] == ""       # exactly 30
    assert s["regression_map"]["note"] == "indicative only"


def test_unknown_decisions_are_refused():
    with pytest.raises(ValueError):
        m.review_summary([{"agent": "a", "decision": "liked"}])


def test_time_summary_is_paired_and_keeps_the_slow_cases():
    t = m.time_summary(PAIRS)
    assert t["n"] == 12
    assert t["median_manual"] == 13.5 and t["median_agent"] == 9.0
    assert t["median_saving"] == 5.5
    assert t["slower_or_equal"] == 2
    assert t["faster_share"]["rate"] == 0.833
    assert t["note"] == "indicative only"
    with pytest.raises(ValueError):
        m.time_summary([])


def test_cost_per_item_arithmetic():
    # 2,000,000 in at 3 per million + 500,000 out at 15 per million
    # = 6 + 7.5 = 13.5 over 100 items
    assert m.cost_per_item(100, 2_000_000, 500_000, 3, 15) == 0.135
    with pytest.raises(ValueError):
        m.cost_per_item(0, 1, 1, 1, 1)


def test_net_value_subtracts_the_agent_s_own_costs():
    v = m.net_value(200, 5.5, 20.0, 30.0, 4.0)
    # 200 x 5.5 min = 1100 min = 18.33 h x 20 = 366.67
    assert v == {"gross": 366.67, "model_cost": 30.0,
                 "upkeep": 80.0, "net": 256.67}
    assert m.net_value(10, 5.5, 20.0, 30.0, 4.0)["net"] < 0
