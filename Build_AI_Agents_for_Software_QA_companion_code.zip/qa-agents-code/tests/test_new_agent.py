import importlib
import json
import subprocess
import sys
from pathlib import Path

import pytest

from qa_agents import new_agent as na

SPEC = json.loads((Path(__file__).parent.parent / "golden"
                   / "spec_changelog.json").read_text("utf-8"))


def test_bad_specs_are_listed_not_guessed():
    assert na.check_spec({})
    bad = dict(SPEC, name="Bad Name")
    assert any("snake_case" in e for e in na.check_spec(bad))
    bad = dict(SPEC, quote_field="nope")
    assert any("not a field" in e for e in na.check_spec(bad))
    bad = dict(SPEC, fields=SPEC["fields"] + [SPEC["fields"][0]])
    assert any("duplicate" in e for e in na.check_spec(bad))
    assert na.check_spec(SPEC) == []


def test_generated_files_import_and_their_own_tests_pass(tmp_path):
    (tmp_path / "tests").mkdir()
    # generate a copy inside the real package tree, in a temp name
    spec = dict(SPEC, name="changelog_demo")
    agents = Path(na.ROOT) / "qa_agents" / "agents"
    tests = tmp_path / "tests"
    made = na.generate(spec, agents, tests)
    try:
        importlib.invalidate_caches()
        mod = importlib.import_module("qa_agents.agents.changelog_demo")
        assert mod.NAME == "changelog_demo"
        r = subprocess.run(
            [sys.executable, "-m", "pytest", "-q", str(made[1]),
             "-p", "no:cacheprovider"], cwd=na.ROOT,
            capture_output=True, text=True)
        assert r.returncode == 0, r.stdout + r.stderr
        assert "4 passed" in r.stdout
    finally:
        made[0].unlink()
        sys.modules.pop("qa_agents.agents.changelog_demo", None)


def test_the_scaffold_never_overwrites(tmp_path):
    (tmp_path / "a").mkdir()
    (tmp_path / "t").mkdir()
    na.generate(SPEC, tmp_path / "a", tmp_path / "t")
    with pytest.raises(FileExistsError):
        na.generate(SPEC, tmp_path / "a", tmp_path / "t")
