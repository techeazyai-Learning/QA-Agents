import json

import pytest

from qa_agents.llm import FunctionLLM, MockLLM
from qa_agents.orchestrator import (BudgetExceeded, Pipeline, Step,
                                    StepLLM, Budget)
from qa_agents.runlog import RunLog


def log(tmp_path):
    return RunLog(tmp_path / "run.jsonl")


def ask(ctx):
    return ctx["llm"].complete("s", "u")


def const(value):
    return lambda ctx: value


def test_order_follows_dependencies_and_keeps_given_order(tmp_path):
    p = Pipeline([Step("c", const(1), needs=("a", "b")),
                  Step("a", const(1)), Step("b", const(1))])
    assert p.order() == ["a", "b", "c"]


def test_bad_pipelines_are_reported():
    p = Pipeline([Step("a", const(1), needs=("b",)),
                  Step("b", const(1), needs=("a",)),
                  Step("a", const(1), level="L9"),
                  Step("c", const(1), needs=("zzz",))])
    errs = p.validate()
    assert "duplicate step 'a'" in errs
    assert "a: unknown level 'L9'" in errs
    assert "c: needs unknown step 'zzz'" in errs
    cyc = Pipeline([Step("a", const(1), needs=("b",)),
                    Step("b", const(1), needs=("a",))])
    assert cyc.validate() == ["the steps contain a cycle"]
    with pytest.raises(ValueError):
        cyc.run(MockLLM([]), RunLog("x.jsonl"))


def test_outputs_flow_downstream(tmp_path):
    p = Pipeline([
        Step("a", const({"n": 2})),
        Step("b", lambda c: c["out"]["a"]["n"] * 21, needs=("a",))])
    rep = p.run(MockLLM([]), log(tmp_path))
    assert rep.results["b"].output == 42 and rep.complete


def test_a_failure_is_never_skipped_silently(tmp_path):
    def boom(ctx):
        raise KeyError("missing")
    p = Pipeline([Step("a", boom), Step("b", const(1), needs=("a",)),
                  Step("c", const(1), needs=("b",)),
                  Step("d", const(1))])
    rep = p.run(MockLLM([]), log(tmp_path))
    assert rep.results["a"].status == "failed"
    assert "KeyError" in rep.results["a"].detail
    assert rep.results["b"].status == "skipped"
    assert "upstream step a is failed" in rep.results["b"].detail
    assert rep.results["c"].status == "skipped"
    assert rep.results["d"].status == "ok"     # independent work runs
    assert not rep.ok and not rep.complete


def test_step_limit_and_zero_means_no_model(tmp_path):
    p = Pipeline([Step("a", ask, max_calls=0),
                  Step("b", lambda c: (ask(c), ask(c)), max_calls=1)])
    rep = p.run(FunctionLLM(lambda s, u: "x"), log(tmp_path))
    assert rep.results["a"].status == "failed"
    assert "limit of 0" in rep.results["a"].detail
    assert rep.results["b"].status == "failed"
    assert rep.results["b"].calls == 1


def test_total_budget_stops_the_run_not_just_a_step(tmp_path):
    p = Pipeline([Step("a", ask, max_calls=5),
                  Step("b", ask, max_calls=5),
                  Step("c", ask, max_calls=5)])
    rep = p.run(FunctionLLM(lambda s, u: "x"), log(tmp_path),
                total_calls=2)
    assert [rep.results[n].status for n in "abc"] == [
        "ok", "ok", "failed"]
    assert "run budget of 2" in rep.results["c"].detail
    assert rep.calls == 2


def test_l2_waits_for_a_named_approval(tmp_path):
    acted = []
    p = Pipeline([
        Step("draft", const("text"), level="L1"),
        Step("send", lambda c: acted.append(c["out"]["draft"]),
             needs=("draft",), level="L2", about="Send the draft"),
        Step("after", const(1), needs=("send",))])
    rep = p.run(MockLLM([]), log(tmp_path), max_level="L2")
    assert rep.results["send"].status == "pending_approval"
    assert rep.results["send"].detail == "Send the draft"
    assert rep.results["after"].status == "waiting"
    assert acted == [] and rep.ok and not rep.complete
    rep = p.run(MockLLM([]), log(tmp_path), max_level="L2",
                approved={"send"})
    assert acted == ["text"] and rep.complete


def test_level_ceiling_beats_approval(tmp_path):
    p = Pipeline([Step("send", const(1), level="L2")])
    rep = p.run(MockLLM([]), log(tmp_path), approved={"send"},
                max_level="L1")
    assert rep.results["send"].status == "refused"
    assert not rep.ok


def test_every_step_is_logged(tmp_path):
    lg = log(tmp_path)
    p = Pipeline([Step("a", const(1)), Step("b", ask, max_calls=1)])
    p.run(FunctionLLM(lambda s, u: "x"), lg)
    rows = [json.loads(x) for x in lg.path.read_text().splitlines()]
    assert [(r["step"], r["status"]) for r in rows] == [
        ("a", "ok"), ("b", "ok")]
    assert rows[1]["calls"] == 1


def test_step_llm_counts_and_caps():
    b = Budget(3)
    s = StepLLM(FunctionLLM(lambda s, u: "x"), b, 2)
    s.complete("s", "u")
    s.complete("s", "u")
    with pytest.raises(BudgetExceeded):
        s.complete("s", "u")
    assert b.used == 2
