import json
from pathlib import Path

from qa_agents import fakes
from qa_agents.agents import payload_check as pc
from qa_agents.llm import FunctionLLM, MockLLM

G = Path(__file__).parent.parent / "golden"
API = json.loads((G / "order_api.json").read_text("utf-8"))
UI = json.loads((G / "order_ui.json").read_text("utf-8"))
MAP = json.loads((G / "order_mapping.json").read_text("utf-8"))


def test_formatters_are_exact():
    f = pc.FORMATTERS
    assert f["money_usd"](1249.5) == "$1,249.50"
    assert f["money_usd"]("0.1") == "$0.10"
    assert f["date_dmy"]("2026-10-24") == "24 Oct 2026"
    assert f["date_dmy"]("2026-03-05T10:00:00Z") == "5 Mar 2026"
    assert f["humanize"]("partially_refunded") == "Partially refunded"
    assert f["count"]([1, 2]) == "2"


def test_flatten_keeps_lists_whole():
    flat = pc.flatten({"a": {"b": 1}, "c": [1, 2]})
    assert flat == {"a.b": 1, "c": [1, 2]}


def test_compare_statuses():
    m = [{"field": "id", "label": "Order", "format": "as_is"},
         {"field": "nope", "label": "Order", "format": "as_is"},
         {"field": "id", "label": "Nope", "format": "as_is"},
         {"field": "delivered_on", "label": "Delivered on",
          "format": "money_usd"}]
    rows = pc.compare(API, UI, m)
    assert [r["status"] for r in rows] == [
        "match", "missing_field", "missing_label", "format_error"]


def test_unmapped_lists_what_nobody_mapped():
    un = pc.unmapped(API, UI, MAP)
    assert "total" in un["api"] and "id" not in un["api"]
    assert "Support hours" in un["ui"] and "Order" not in un["ui"]


def test_stand_in_finds_the_two_real_rendering_bugs():
    res = pc.validate(FunctionLLM(fakes.fake_payload_map), API, UI, MAP)
    assert res.ok
    bad = {r["field"]: r for r in res.proposed
           if r["status"] == "mismatch"}
    assert set(bad) == {"total", "delivered_on"}
    assert bad["total"]["actual"] == "$1,249.5"
    assert bad["delivered_on"]["expected"] == "24 Oct 2026"
    assert bad["delivered_on"]["actual"] == "23 Oct 2026"
    assert "internal_risk_score" in res.not_displayed


def test_proposal_for_a_mapped_or_unknown_field_is_rejected():
    bad = json.dumps({"proposals": [{
        "field": "id", "label": "Order", "format": "as_is",
        "reason": "x"}], "not_displayed": []})
    llm = MockLLM([bad] * 3)
    res = pc.validate(llm, API, UI, MAP)
    assert not res.ok
    assert "not an unmapped API field" in llm.calls[1]["user"]


def test_same_label_cannot_be_used_twice():
    p = {"field": "total", "label": "Order total",
         "format": "money_usd", "reason": "x"}
    q = {**p, "field": "refunded"}
    bad = json.dumps({"proposals": [p, q], "not_displayed": []})
    llm = MockLLM([bad] * 3)
    pc.validate(llm, API, UI, MAP)
    assert "label used twice" in llm.calls[1]["user"]


def test_no_model_call_when_everything_is_mapped():
    full = [{"field": k, "label": k, "format": "as_is"} for k in UI]
    api = {k: "v" for k in UI}
    llm = MockLLM([])
    assert pc.validate(llm, api, UI, full).ok and llm.calls == []
