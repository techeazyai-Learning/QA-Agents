import json
from pathlib import Path

from qa_agents import fakes
from qa_agents.agents import perf_scenarios as ps
from qa_agents.llm import FunctionLLM, MockLLM

PROFILE = json.loads((Path(__file__).parent.parent / "golden"
                      / "traffic_profile.json").read_text("utf-8"))
PLAN = ps.scenarios(PROFILE)


def test_rates_are_exact_arithmetic():
    s1 = PLAN[0]
    assert s1["rates"]["POST /orders/{id}/refunds"] == 0.667
    assert s1["per_minute"]["GET /orders/{id}"] == 300
    assert s1["total_rps"] == 6.667
    assert PLAN[1]["multiplier"] == 1.5
    assert PLAN[1]["rates"]["GET /orders/{id}"] == 7.5


def test_virtual_users_follow_littles_law():
    # 6.667 requests/s x (0.8 s response + 6 s think) = 45.3 -> 46
    assert PLAN[0]["virtual_users"] == 46
    assert PLAN[2]["virtual_users"] == 136


def test_profile_problems_are_reported():
    bad = dict(PROFILE, peak_hour_requests={"GET /x": 0})
    assert "GET /x: requests per hour must be > 0" in \
        ps.check_profile(bad)
    assert ps.check_profile({}) != []


def test_numbers_in_ignores_digits_inside_names():
    assert ps.numbers_in("S3 at p95 is 800 ms, 0.667 per second") \
        == {"800", "0.667"}
    assert ps.numbers_in("1.0 and 1") == {"1"}


def reply(**over):
    item = {"id": "S1", "purpose": "Check peak.", "watch": ["errors"],
            "risks": [{"endpoint": "GET /orders/{id}",
                       "risk": "Slow."}]}
    items = [dict(item, id=f"S{i}") for i in range(1, 5)]
    items[0].update(over)
    return json.dumps({"scenarios": items, "questions": []})


def test_model_may_not_state_numbers_the_plan_lacks():
    bad = reply(purpose="Expect 500 requests per second.")
    llm = MockLLM([bad] * 3)
    res = ps.design(llm, PROFILE)
    assert not res.ok
    assert "the number '500' is not in the plan" in llm.calls[1]["user"]


def test_plan_numbers_are_allowed_and_ids_are_required():
    ok = reply(purpose="Run S1 at 6.667 requests per second.")
    assert ps.design(MockLLM([ok]), PROFILE).ok
    short = json.dumps({"scenarios": json.loads(ok)["scenarios"][:2],
                        "questions": []})
    llm = MockLLM([short] * 3)
    assert not ps.design(llm, PROFILE).ok
    assert "missing scenario S3" in llm.calls[1]["user"]


def test_unknown_endpoint_is_rejected():
    bad = reply(risks=[{"endpoint": "GET /secret", "risk": "x"}])
    llm = MockLLM([bad] * 3)
    ps.design(llm, PROFILE)
    assert "unknown endpoint 'GET /secret'" in llm.calls[1]["user"]


def test_k6_script_is_deterministic_and_uses_plan_numbers():
    a = ps.k6_script(PROFILE, PLAN[2])
    assert a == ps.k6_script(PROFILE, PLAN[2])
    assert "target: 900" in a and "duration: '300s'" in a
    assert "p(95)<800" in a and "rate<0.01" in a


def test_invalid_profile_never_reaches_the_model():
    llm = MockLLM([])
    res = ps.design(llm, {})
    assert not res.ok and llm.calls == []


def test_stand_in_end_to_end():
    res = ps.design(FunctionLLM(fakes.fake_perf), PROFILE)
    assert res.ok, res.errors
    assert [s["id"] for s in res.data["scenarios"]] == \
        ["S1", "S2", "S3", "S4"]
