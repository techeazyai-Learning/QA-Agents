from qa_agents.redact import redact


def test_email_and_secret_are_removed():
    out = redact("mail a.b@example.com password=hunter2 now")
    assert "example.com" not in out.text
    assert "hunter2" not in out.text
    assert out.counts["EMAIL"] == 1
    assert out.counts["SECRET"] == 1


def test_bearer_and_long_token():
    out = redact("Authorization: Bearer abcdefghijklmnopqrstuvwxyz123456")
    assert "abcdefghijklmnop" not in out.text
    out = redact("id " + "A1b2C3d4" * 5)
    assert out.counts.get("LONGTOKEN") == 1


def test_phone_number():
    out = redact("call 415-555-0134 please")
    assert "555-0134" not in out.text


def test_plain_text_is_unchanged():
    out = redact("Click Save and the page reloads.")
    assert out.total == 0
    assert out.text == "Click Save and the page reloads."
