from qa_agents import redteam


def test_every_attack_ends_as_written_down():
    rows = redteam.run_all()
    assert len(rows) == 16
    bad = [r for r in rows if not r["as_expected"]]
    assert bad == []


def test_injected_text_is_always_inside_the_fence():
    assert all(r["fenced"] for r in redteam.run_all())


def test_the_gaps_are_the_semantic_attacks():
    through = [r["id"] for r in redteam.run_all()
               if r["got"] == "got through"]
    assert through == ["A2", "A4", "A9", "A11", "A13"]


def test_stopped_attacks_name_the_right_guard():
    for aid in redteam.WHY:
        assert aid in {a[0] for a in redteam.ATTACKS}
    stopped = {r["id"] for r in redteam.run_all()
               if r["got"] == "stopped"}
    assert stopped == set(redteam.WHY)
