import json
from pathlib import Path

from qa_agents import fakes
from qa_agents.agents import regression_map as rm
from qa_agents.llm import FunctionLLM, MockLLM

G = Path(__file__).parent.parent / "golden"
BUGS = json.loads((G / "fixed_bugs.json").read_text("utf-8"))
TESTS = json.loads((G / "test_catalog.json").read_text("utf-8"))
B1, B4 = BUGS[0], BUGS[3]


def item(**over):
    d = {"bug_id": "FIX-1", "outcome": "partial",
         "test_id": "test_refund_amount_limits",
         "explanation": "Checks one refund only.",
         "new_test_title": "Cumulative refunds stay within the limit",
         "level": "api",
         "steps": ["Refund 20.00", "Refund 120.00 on the same order"],
         "expected": "The second refund is rejected."}
    d.update(over)
    return d


def errors(d, bug=B1):
    cands = rm.candidates(bug, TESTS)
    return rm.make_agent(bug, cands, TESTS).extra_checks(d)


def test_candidates_combine_words_and_fixed_files():
    c = rm.candidates(BUGS[2], TESTS)
    assert c[0] == "test_order_status_rules"
    assert "test_refund_amount_limits" in rm.candidates(B1, TESTS)


def test_a_valid_partial_passes_all_checks():
    assert errors(item()) == []


def test_gap_must_not_name_a_test_and_covered_needs_no_new_test():
    assert "a gap has no test_id" in errors(
        item(outcome="gap", test_id="test_login"), B4)
    cov = item(outcome="covered", level="ui")
    assert "covered needs no new test" in errors(cov)


def test_test_id_must_be_a_candidate():
    assert any("not a candidate" in e for e in errors(
        item(test_id="test_login")))


def test_new_test_needs_title_steps_expected_and_level():
    bad = item(new_test_title="", steps=[], expected="", level="none")
    e = errors(bad)
    assert "a new test needs title, steps, expected" in e
    assert "choose unit, api or ui" in e


def test_new_test_must_not_copy_an_existing_one():
    e = errors(item(new_test_title="Refund amount limits"))
    assert any("looks like existing test" in x for x in e)


def test_numbers_must_come_from_the_bug_text():
    e = errors(item(steps=["Refund 250.00"]))
    assert "the number '250' is not in the bug text" in e
    assert errors(item(steps=["Refund 20 then 120"])) == []


def test_wrong_bug_id_is_rejected():
    assert "bug_id must be FIX-1" in errors(item(bug_id="FIX-2"))


def test_stand_in_end_to_end_and_scoring():
    res = rm.map_bugs(FunctionLLM(fakes.fake_regression), BUGS, TESTS)
    assert res.ok and len(res.items) == 4
    s = rm.score_outcomes(res.items, BUGS)
    assert s["agreement"] == 0.5 and set(s["wrong"]) == {"FIX-3",
                                                         "FIX-4"}
    assert rm.summary(res.items)["needs_new_test"] == 4
    assert rm.backlog_csv(res.items).startswith("bug,outcome")


def test_failure_is_reported_per_bug():
    res = rm.map_bugs(MockLLM(["nope"] * 12), BUGS[:1], TESTS)
    assert not res.ok and "FIX-1" in res.errors
