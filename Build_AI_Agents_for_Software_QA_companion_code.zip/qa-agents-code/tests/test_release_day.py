import json
from pathlib import Path

from qa_agents import fakes
from qa_agents.llm import FunctionLLM, MockLLM
from qa_agents.release_day import build
from qa_agents.runlog import RunLog

G = Path(__file__).parent.parent / "golden"


def load(name):
    return json.loads((G / name).read_text("utf-8"))


def make(tmp_path):
    return build(load("test_runs.json"),
                 load("release_evidence.json"),
                 load("release_gates.json"), tmp_path / "outbox")


def test_full_run_stops_at_the_approval(tmp_path):
    rep = make(tmp_path).run(FunctionLLM(fakes.fake_router),
                             RunLog(tmp_path / "l.jsonl"),
                             max_level="L2", total_calls=12)
    status = {n: r.status for n, r in rep.results.items()}
    assert status == {"triage": "ok", "scorecard": "ok",
                      "report_exec": "ok", "report_eng": "ok",
                      "packet": "ok", "publish": "pending_approval"}
    assert rep.calls == 4
    assert not (tmp_path / "outbox").exists()
    packet = rep.results["packet"].output
    assert "# Release packet 2026.10.3 (draft)" in packet
    assert "[F2]" in packet
    assert "test_refund_amount_limits: fix now" in packet


def test_approval_publishes_the_packet(tmp_path):
    rep = make(tmp_path).run(FunctionLLM(fakes.fake_router),
                             RunLog(tmp_path / "l.jsonl"),
                             max_level="L2", approved={"publish"})
    assert rep.complete
    out = Path(rep.results["publish"].output)
    assert out.name == "release_2026.10.3.md" and out.exists()


def test_default_ceiling_refuses_publication(tmp_path):
    rep = make(tmp_path).run(FunctionLLM(fakes.fake_router),
                             RunLog(tmp_path / "l.jsonl"),
                             approved={"publish"})
    assert rep.results["publish"].status == "refused"
    assert not (tmp_path / "outbox").exists()


def test_a_broken_model_stops_the_dependent_steps(tmp_path):
    rep = make(tmp_path).run(MockLLM(["not json"] * 30),
                             RunLog(tmp_path / "l.jsonl"),
                             max_level="L2", approved={"publish"})
    status = {n: r.status for n, r in rep.results.items()}
    assert status["triage"] == "failed"
    assert status["scorecard"] == "failed"
    assert status["report_exec"] == "skipped"
    assert status["packet"] == "skipped"
    assert status["publish"] == "skipped"
    assert not (tmp_path / "outbox").exists()


def test_a_tight_budget_fails_a_step_visibly(tmp_path):
    rep = make(tmp_path).run(FunctionLLM(fakes.fake_router),
                             RunLog(tmp_path / "l.jsonl"),
                             total_calls=2)
    assert rep.results["report_exec"].status == "failed"
    assert "run budget of 2" in rep.results["report_exec"].detail
