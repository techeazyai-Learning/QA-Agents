import copy
import json
from pathlib import Path

from qa_agents import fakes
from qa_agents.agents import release_readiness as rr
from qa_agents.llm import FunctionLLM, MockLLM

G = Path(__file__).parent.parent / "golden"
EV = json.loads((G / "release_evidence.json").read_text("utf-8"))
CF = json.loads((G / "release_gates.json").read_text("utf-8"))


def status(ev=EV, cf=CF):
    return {r["id"]: r["status"] for r in rr.evaluate(ev, cf)}


def test_sample_statuses():
    assert status() == {"G1": "pass", "G2": "fail", "G3": "pass",
                        "G4": "fail", "G5": "unknown", "G6": "pass",
                        "G7": "waived", "G8": "fail",
                        "G9": "unknown"}
    rows = rr.evaluate(EV, CF)
    assert rr.overall(rows) == "blocked"
    assert rr.counts(rows) == {"pass": 3, "fail": 3, "unknown": 2,
                               "waived": 1}


def test_missing_evidence_is_unknown_never_pass():
    ev = copy.deepcopy(EV)
    del ev["suites"]
    del ev["bugs"]
    got = status(ev)
    assert got["G1"] == "unknown" and got["G3"] == "unknown"
    assert got["G4"] == "unknown"


def test_the_workaround_rule_and_closed_bugs():
    ev = copy.deepcopy(EV)
    ev["bugs"][0]["workaround"] = True
    assert status(ev)["G4"] == "pass"
    ev["bugs"].append({"id": "BUG-9", "title": "t",
                       "severity": "critical", "status": "closed",
                       "workaround": False})
    assert status(ev)["G3"] == "pass"
    ev["bugs"][-1]["status"] = "reopened"
    assert status(ev)["G3"] == "fail"


def test_date_gate_counts_days_from_as_of_not_today():
    ev = copy.deepcopy(EV)
    ev["performance_last_run"] = "2026-10-06"
    assert status(ev)["G8"] == "pass"       # exactly 14 days
    ev["performance_last_run"] = "2026-10-05"
    assert status(ev)["G8"] == "fail"
    ev["performance_last_run"] = "2026-11-01"
    assert status(ev)["G8"] == "unknown"    # after as_of


def test_environment_gate():
    ev = copy.deepcopy(EV)
    ev["environments_tested"] = ["staging-eu"]
    assert status(ev)["G9"] == "fail"
    ev["environments_tested"] = ["staging-eu", "staging-us"]
    assert status(ev)["G9"] == "pass"


def test_a_waiver_needs_a_name_and_a_reason():
    cf = copy.deepcopy(CF)
    cf["waivers"][0]["approved_by"] = " "
    assert rr.check_config(cf) == [
        "waiver for G7: needs a named approver and a reason"]
    cf["waivers"] = [{"gate": "G99", "approved_by": "x",
                      "reason": "y"}]
    assert "waiver for unknown gate 'G99'" in rr.check_config(cf)


def test_waiver_keeps_the_gap_visible_and_cannot_hide_a_pass():
    row = {r["id"]: r for r in rr.evaluate(EV, CF)}["G7"]
    assert row["status"] == "waived" and row["was"] == "fail"
    assert "waived by Release manager" in row["detail"]
    cf = copy.deepcopy(CF)
    cf["waivers"].append({"gate": "G1", "approved_by": "a",
                          "reason": "b"})
    assert status(EV, cf)["G1"] == "pass"


def test_overall_rules():
    def row(st, blocking):
        return {"status": st, "blocking": blocking}
    assert rr.overall([row("pass", True)]) == "criteria_met"
    assert rr.overall([row("fail", False)]) == "attention"
    assert rr.overall([row("waived", True)]) == "attention"
    assert rr.overall([row("unknown", True),
                       row("fail", False)]) == "incomplete"
    assert rr.overall([row("unknown", True),
                       row("fail", True)]) == "blocked"


def test_bad_config_is_reported_and_stops_the_run():
    cf = {"gates": [{"id": "A", "title": "t", "blocking": "yes",
                     "kind": "nonsense"},
                    {"id": "A", "title": "t", "blocking": True,
                     "kind": "open_bugs"}]}
    errs = rr.check_config(cf)
    assert "duplicate gate id 'A'" in errs
    assert any("unknown kind 'nonsense'" in e for e in errs)
    llm = MockLLM([])
    res = rr.scorecard(llm, EV, cf)
    assert not res.ok and llm.calls == []


def notes(items=None, summary="Some gates are not met."):
    if items is None:
        items = [{"gate": g, "meaning": "m", "options": ["o"],
                  "questions": []}
                 for g in ("G2", "G4", "G5", "G7", "G8", "G9")]
    return json.dumps({"summary": summary, "items": items})


def test_every_unmet_gate_needs_an_item_and_passes_need_none():
    items = [{"gate": g, "meaning": "m", "options": ["o"],
              "questions": []} for g in ("G2", "G1")]
    llm = MockLLM([notes(items)] * 3)
    assert not rr.scorecard(llm, EV, CF).ok
    msg = llm.calls[1]["user"]
    assert "no item for gate G4" in msg
    assert "gate G1 is pass and needs no item" in msg


def test_model_may_not_declare_the_release_safe():
    llm = MockLLM([notes(summary="It is safe to release now.")] * 3)
    res = rr.scorecard(llm, EV, CF)
    assert not res.ok
    assert "banned claim 'safe to release'" in llm.calls[1]["user"]


def test_numbers_must_come_from_the_scorecard():
    ok = json.loads(notes())
    ok["items"][0]["meaning"] = "The smoke run had 40 tests."
    assert rr.scorecard(MockLLM([json.dumps(ok)]), EV, CF).ok
    bad = json.loads(notes())
    bad["items"][0]["meaning"] = "Roughly 73 per cent are affected."
    llm = MockLLM([json.dumps(bad)] * 3)
    assert not rr.scorecard(llm, EV, CF).ok
    assert "the number '73' is not in the scorecard" in \
        llm.calls[1]["user"]


def test_all_pass_skips_the_model():
    cf = {"gates": [CF["gates"][0]]}
    llm = MockLLM([])
    res = rr.scorecard(llm, EV, cf)
    assert res.ok and res.overall == "criteria_met"
    assert res.notes is None and llm.calls == []


def test_stand_in_end_to_end():
    res = rr.scorecard(FunctionLLM(fakes.fake_readiness), EV, CF)
    assert res.ok, res.errors
    assert res.overall == "blocked"
    assert [i["gate"] for i in res.notes["items"]] == \
        ["G2", "G4", "G5", "G7", "G8", "G9"]
