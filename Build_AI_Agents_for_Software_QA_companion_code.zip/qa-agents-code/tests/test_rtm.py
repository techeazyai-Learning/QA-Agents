import json
from pathlib import Path

from qa_agents import fakes
from qa_agents.agents import rtm
from qa_agents.llm import FunctionLLM, MockLLM

D = json.loads((Path(__file__).parent.parent / "golden"
                / "rtm.json").read_text("utf-8"))
REQ, TESTS = D["requirements"], D["tests"]


def link(r, t, strength="full", quote=None):
    return {"requirement_id": r, "test_id": t, "strength": strength,
            "quote": quote or "Cancelled orders", "rationale": "x"}


def test_candidates_are_ranked_stable_and_limited():
    c = rtm.candidates(REQ, TESTS, k=2)
    assert all(len(v) <= 2 for v in c.values())
    assert c["R4"][0] == "T5"
    assert c == rtm.candidates(REQ, TESTS, k=2)


def test_link_to_non_candidate_is_rejected():
    cands = {"R4": ["T5"]}
    reqs = [REQ[3]]
    agent = rtm.make_agent(reqs, cands)
    bad = {"links": [link("R4", "T1")]}
    assert any("not a candidate" in e for e in agent.extra_checks(bad))


def test_invented_quote_is_rejected():
    cands = {"R4": ["T5"]}
    agent = rtm.make_agent([REQ[3]], cands)
    bad = {"links": [link("R4", "T5", quote="made up words")]}
    assert any("quote is not in R4" in e
               for e in agent.extra_checks(bad))


def test_matrix_status_is_computed_by_code():
    links = [link("R1", "T1"), link("R2", "T2", "partial")]
    m = rtm.build_matrix(REQ, TESTS, links)
    assert m["rows"]["R1"]["status"] == "covered"
    assert m["rows"]["R2"]["status"] == "partial"
    assert m["rows"]["R3"]["status"] == "uncovered"
    assert "T3" in m["orphan_tests"] and "T1" not in m["orphan_tests"]


def test_trace_end_to_end_with_stand_in():
    res = rtm.trace(FunctionLLM(fakes.fake_rtm_links), REQ, TESTS)
    assert res.ok
    assert res.matrix["rows"]["R6"]["status"] == "uncovered"
    assert "T7" in res.matrix["orphan_tests"]
    csv_text = rtm.matrix_csv(res.matrix)
    assert csv_text.splitlines()[0] == "requirement,status,tests"


def test_trace_fails_visibly_on_bad_model_output():
    res = rtm.trace(MockLLM(["nope"] * 3), REQ, TESTS)
    assert not res.ok and res.matrix == {}


def test_score_links_reports_the_search_ceiling():
    cands = {"R1": ["T1"], "R2": ["T2"]}
    golden = [{"requirement_id": "R1", "test_id": "T1"},
              {"requirement_id": "R2", "test_id": "T9"}]
    got = [link("R1", "T1"), link("R2", "T2")]
    s = rtm.score_links(got, golden, cands)
    assert s["precision"] == 0.5 and s["recall"] == 0.5
    assert s["candidate_recall"] == 0.5
    assert s["missed"] == [("R2", "T9")]
