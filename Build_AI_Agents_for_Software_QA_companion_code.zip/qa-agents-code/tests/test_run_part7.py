import run_part7


def test_each_chapter_runs_offline(tmp_path, capsys, monkeypatch):
    monkeypatch.chdir(run_part7.Path(__file__).parent.parent)
    assert run_part7.main(["ch26"]) == 0
    assert run_part7.main(["ch27"]) == 0
    assert run_part7.main(["ch28", "--out", str(tmp_path / "g")]) == 0
    assert run_part7.main(["ch25", "--outbox",
                           str(tmp_path / "o")]) == 0
    assert not (tmp_path / "o").exists()      # no approval, no publish
    capsys.readouterr()
