import pytest

from qa_agents.schema import extract_json, validate

SCHEMA = {
    "type": "object",
    "additionalProperties": False,
    "required": ["a"],
    "properties": {
        "a": {"type": "integer", "minimum": 1, "maximum": 5},
        "b": {"type": "array", "maxItems": 2,
              "items": {"type": "string", "enum": ["x", "y"]}},
    },
}


def test_valid_object_has_no_errors():
    assert validate({"a": 3, "b": ["x"]}, SCHEMA) == []


def test_missing_required_and_wrong_type():
    assert validate({}, SCHEMA)
    assert validate({"a": "3"}, SCHEMA)


def test_bool_is_not_an_integer():
    assert validate({"a": True}, SCHEMA)


def test_range_enum_items_and_extra_keys():
    assert validate({"a": 9}, SCHEMA)
    assert validate({"a": 1, "b": ["z"]}, SCHEMA)
    assert validate({"a": 1, "b": ["x", "y", "x"]}, SCHEMA)
    assert validate({"a": 1, "c": 1}, SCHEMA)


def test_extract_json_plain_fenced_and_chatty():
    assert extract_json('{"a": 1}') == {"a": 1}
    assert extract_json('```json\n{"a": 1}\n```') == {"a": 1}
    assert extract_json('Sure! {"a": 1} Hope it helps.') == {"a": 1}


def test_extract_json_rejects_garbage():
    with pytest.raises(ValueError):
        extract_json("no json here")
    with pytest.raises(ValueError):
        extract_json("{not json}")
