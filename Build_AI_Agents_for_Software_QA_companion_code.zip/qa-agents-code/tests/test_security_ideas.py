import json
from pathlib import Path

from qa_agents import fakes
from qa_agents.agents import security_ideas as si
from qa_agents.llm import FunctionLLM, MockLLM

G = Path(__file__).parent.parent / "golden"
SPEC = (G / "security_feature.txt").read_text("utf-8")
RULES = json.loads((G / "security_rules.json").read_text("utf-8"))
FOUND = si.find_traits(SPEC, RULES)


def idea(ref, quote, text="Try a far longer value.", **over):
    d = {"trait": ref, "feature_quote": quote, "test_idea": text,
         "secure_result": "Refused.", "level": "api"}
    d.update(over)
    return d


def full_reply(**over):
    ideas = [idea(f["ref"], f["sentence"]) for f in FOUND]
    ideas[0].update(over)
    return json.dumps({"ideas": ideas})


def test_traits_are_found_by_code_with_their_sentences():
    ids = [f["id"] for f in FOUND]
    assert ids == ["object_reference", "roles", "sign_in",
                   "free_text", "file_upload", "money",
                   "email_output", "audit"]
    by = {f["id"]: f for f in FOUND}
    assert "/orders/{orderId}" in by["object_reference"]["sentence"]
    assert "above 500.00" in by["money"]["sentence"]
    assert by["audit"]["category"] == "A09"


def test_description_without_any_trait_skips_the_model():
    llm = MockLLM([])
    res = si.design(llm, "The page shows a greeting.", RULES)
    assert res.ok and res.ideas == [] and llm.calls == []


def test_every_trait_needs_an_idea():
    short = json.dumps({"ideas": [idea(FOUND[0]["ref"],
                                       FOUND[0]["sentence"])]})
    llm = MockLLM([short] * 3)
    res = si.design(llm, SPEC, RULES)
    assert not res.ok
    assert "no idea for trait T2" in llm.calls[1]["user"]


def test_quote_must_come_from_the_description():
    bad = full_reply(feature_quote="The agent can delete users.")
    llm = MockLLM([bad] * 3)
    si.design(llm, SPEC, RULES)
    assert "quote is not in the description" in llm.calls[1]["user"]


def test_unknown_trait_is_rejected():
    bad = full_reply(trait="T99")
    llm = MockLLM([bad] * 3)
    si.design(llm, SPEC, RULES)
    assert "unknown trait 'T99'" in llm.calls[1]["user"]


def test_ready_made_attack_strings_are_rejected():
    for text in ["Type <script>alert(1)</script> in the note.",
                 "Send ' OR 1=1 -- as the value.",
                 "Request ../../etc/passwd as the file.",
                 "Use UNION SELECT to read other tables."]:
        assert si.payload_hits(text), text
        llm = MockLLM([full_reply(test_idea=text)] * 3)
        res = si.design(llm, SPEC, RULES)
        assert not res.ok
        assert "not a ready-made attack string" in \
            llm.calls[1]["user"]
    assert not si.payload_hits("A value far longer than allowed, "
                               "and characters with special meaning.")


def test_stand_in_end_to_end_and_grouping():
    res = si.design(FunctionLLM(fakes.fake_security), SPEC, RULES)
    assert res.ok, res.errors
    assert len(res.ideas) == 8
    groups = si.by_category(res)
    assert list(groups) == ["A01", "A03", "A04", "A05", "A07", "A09"]
    assert len(groups["A01"]) == 2 and len(groups["A03"]) == 2
    assert res.banner.startswith("Use these ideas only")
