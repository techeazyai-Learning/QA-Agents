import pytest

from qa_agents.techniques import boundary_values, suggested_inputs


def test_boundary_values_integer():
    assert boundary_values(1, 10) == ["0", "1", "2", "9", "10", "11"]


def test_boundary_values_money_has_no_float_noise():
    assert boundary_values("0.01", "120.00", "0.01") == [
        "0", "0.01", "0.02", "119.99", "120", "120.01"]


def test_boundary_values_narrow_range_has_no_duplicates():
    vals = boundary_values(5, 6)
    assert vals == sorted(set(vals), key=float)


def test_min_above_max_is_an_error():
    with pytest.raises(ValueError):
        boundary_values(5, 1)


def test_suggested_inputs_by_kind():
    r = suggested_inputs({"kind": "range", "min": "1", "max": "3"})
    assert r["valid"] == ["1", "2", "3"] and r["invalid"] == ["0", "4"]
    e = suggested_inputs({"kind": "enum", "values": ["a", "b"]})
    assert e["valid"] == ["a", "b"] and "" in e["invalid"]
    s = suggested_inputs({"kind": "state", "allowed": ["x"],
                          "others": ["y"]})
    assert s == {"valid": ["x"], "invalid": ["y"]}
    assert suggested_inputs({"kind": "behavior"}) == {
        "valid": [], "invalid": []}
