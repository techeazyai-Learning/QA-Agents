import csv
import io
import json
from pathlib import Path

from qa_agents import fakes
from qa_agents.agents import test_case_generator as tg
from qa_agents.llm import FunctionLLM, MockLLM

SPEC = json.loads((Path(__file__).parent.parent / "golden"
                   / "refund_rules.json").read_text(encoding="utf-8"))


def case(title="Sample case title", rules=("R1",)):
    return {"title": title, "type": "positive", "rule_ids": list(rules),
            "preconditions": [], "steps": ["Do it"],
            "expected": ["It works"], "priority": "P2"}


def test_input_contains_calculated_boundaries():
    text = tg.build_input(SPEC["feature"], SPEC["rules"])
    assert "119.99" in text and "120.01" in text
    assert "cancelled" in text


def test_stand_in_covers_every_rule_and_ids_come_from_code():
    res = tg.generate_cases(FunctionLLM(fakes.fake_generate_cases),
                            SPEC["feature"], SPEC["rules"])
    assert res.ok and res.coverage["uncovered"] == []
    assert [c["id"] for c in res.cases][:2] == ["TC-001", "TC-002"]
    assert len({c["id"] for c in res.cases}) == len(res.cases)


def test_unknown_rule_and_duplicate_titles_are_rejected():
    bad = json.dumps({"cases": [case("Same title here", ["R9"]),
                                case("same  title here")]})
    llm = MockLLM([bad, json.dumps({"cases": [case()]})])
    res = tg.generate_cases(llm, SPEC["feature"], SPEC["rules"])
    assert res.ok and len(res.cases) == 1
    assert "R9" in llm.calls[1]["user"]
    assert "duplicate title" in llm.calls[1]["user"]


def test_coverage_reports_uncovered_rules():
    cov = tg.coverage([{"rule_ids": ["R1"]}], SPEC["rules"])
    assert cov["uncovered"] == ["R2", "R3", "R4"]


def test_gherkin_and_csv_exports():
    c = {"id": "TC-001", **case("Refund works")}
    c["preconditions"] = ["A delivered order"]
    g = tg.to_gherkin(c)
    assert g.splitlines() == [
        "Scenario: Refund works", "  Given A delivered order",
        "  When Do it", "  Then It works"]
    rows = list(csv.reader(io.StringIO(tg.to_csv([c]))))
    assert rows[0][0] == "id" and rows[1][0] == "TC-001"
    assert rows[1][6] == "1. Do it"


def test_input_gaps_find_boundary_values_no_case_uses():
    rules = [SPEC["rules"][0]]
    one = case("Only the lower edge", ["R1"])
    one["steps"] = ["Enter 0.01", "Submit"]
    gaps = tg.input_gaps([one], rules)
    assert gaps["R1"] == ["0.02", "119.99", "120", "0", "120.01"]


def test_input_gaps_compare_numbers_not_text_and_clear_when_used():
    rules = [SPEC["rules"][0]]
    c = case("All six values", ["R1"])
    c["steps"] = ["Try 0.00, 0.01, 0.02, 119.99, 120.00 and 120.01"]
    assert tg.input_gaps([c], rules) == {}


def test_stand_in_misses_the_maximum_value():
    res = tg.generate_cases(FunctionLLM(fakes.fake_generate_cases),
                            SPEC["feature"], SPEC["rules"])
    assert res.gaps == {"R1": ["120"], "R2": ["other"]}
