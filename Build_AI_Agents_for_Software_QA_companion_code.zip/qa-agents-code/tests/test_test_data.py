import json
from pathlib import Path

import pytest

from qa_agents import fakes
from qa_agents.agents import test_data as td
from qa_agents.llm import FunctionLLM, MockLLM

G = Path(__file__).parent.parent / "golden"
FIELDS = json.loads((G / "refund_fields.json").read_text("utf-8"))
AMOUNT = {"name": "refund_amount", "type": "decimal",
          "min": "0.01", "max": "120.00"}


def plan():
    return td.plan_test_data(FunctionLLM(fakes.fake_test_data),
                             [{"id": "TC-001", "title": "x"}], FIELDS)


def test_recipe_valid_must_stay_inside_limits():
    ok = {"field": "refund_amount", "purpose": "valid",
          "generator": "decimal_range",
          "params": {"min": "1", "max": "50"}}
    assert td.recipe_errors(ok, AMOUNT) == []
    leaks = {**ok, "params": {"min": "1", "max": "500"}}
    assert "leaves the limits" in td.recipe_errors(leaks, AMOUNT)[0]


def test_recipe_invalid_must_break_a_limit():
    inside = {"field": "refund_amount", "purpose": "invalid",
              "generator": "decimal_range",
              "params": {"min": "1", "max": "50"}}
    assert "stays in limits" in td.recipe_errors(inside, AMOUNT)[0]


def test_wrong_generator_for_type_is_rejected():
    r = {"field": "refund_amount", "purpose": "valid",
         "generator": "email", "params": {}}
    assert "does not fit" in td.recipe_errors(r, AMOUNT)[0]


def test_plan_passes_checks_and_every_field_has_a_valid_recipe():
    p = plan()
    assert p.ok
    have = {r["field"] for r in p.recipes if r["purpose"] == "valid"}
    assert have == {f["name"] for f in FIELDS}


def test_missing_valid_recipe_is_rejected():
    bad = json.dumps({"needs": [], "recipes": []})
    res = td.plan_test_data(MockLLM([bad] * 3), [], FIELDS)
    assert not res.ok and any("no valid recipe" in e
                              for e in res.errors)


def test_synthesis_is_deterministic_and_seed_sensitive():
    p = plan()
    a = td.synthesize(p.recipes, FIELDS, rows=4, seed=3)
    b = td.synthesize(p.recipes, FIELDS, rows=4, seed=3)
    c = td.synthesize(p.recipes, FIELDS, rows=4, seed=4)
    assert a == b and a != c


def test_valid_rows_respect_dictionary_and_uniqueness():
    p = plan()
    data = td.synthesize(p.recipes, FIELDS, rows=20, seed=1)
    amounts = [float(r["refund_amount"]) for r in data["valid"]]
    assert all(0.01 <= a <= 120.0 for a in amounts)
    assert len({r["customer_email"] for r in data["valid"]}) == 20
    assert all(r["reason"] in FIELDS[3]["values"]
               for r in data["valid"])


def test_invalid_rows_break_exactly_one_field():
    p = plan()
    data = td.synthesize(p.recipes, FIELDS, rows=3, seed=1)
    base = data["valid"][0]
    assert data["invalid"]
    for item in data["invalid"]:
        diff = [k for k in base if base[k] != item["row"][k]]
        assert diff == [item["faulty_field"]]


def test_overrides_pin_a_field_and_are_validated():
    p = plan()
    data = td.synthesize(p.recipes, FIELDS, rows=5,
                         overrides={"order_status": "delivered"})
    assert {r["order_status"] for r in data["valid"]} == {"delivered"}
    with pytest.raises(ValueError):
        td.synthesize(p.recipes, FIELDS,
                      overrides={"order_status": "teleported"})
    with pytest.raises(ValueError):
        td.synthesize(p.recipes, FIELDS, overrides={"nope": 1})


def test_generated_data_is_clean_and_pii_scan_catches_real_looking():
    p = plan()
    assert td.pii_risks(td.synthesize(p.recipes, FIELDS)) == []
    risks = td.pii_risks({"e": "jane@gmail.com", "p": "415-555-0132"})
    assert any("real-looking email" in r for r in risks)
    assert any("phone-like" in r for r in risks)
