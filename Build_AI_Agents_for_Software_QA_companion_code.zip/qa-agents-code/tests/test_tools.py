import json

from qa_agents.llm import MockLLM
from qa_agents.tools import Tool, ToolRegistry, run_tool_loop


def registry():
    reg = ToolRegistry()
    reg.register(Tool("add", "add two numbers",
                      lambda a, b: a + b))
    reg.register(Tool("wipe", "delete everything",
                      lambda: "gone", read_only=False))
    return reg


def call(tool, **args):
    return json.dumps({"action": "tool", "tool": tool, "args": args})


FINAL = json.dumps({"action": "final", "result": {"sum": 5}})


def test_tool_then_final():
    llm = MockLLM([call("add", a=2, b=3), FINAL])
    res = run_tool_loop(llm, "sys", "add", registry())
    assert res.ok and res.final == {"sum": 5} and res.steps == 2
    assert "Observation (add): 5" in llm.calls[1]["user"]


def test_unknown_tool_and_bad_args_become_observations():
    llm = MockLLM([call("nope"), call("add", a=1), FINAL])
    res = run_tool_loop(llm, "sys", "t", registry())
    assert res.ok
    assert "unknown tool" in llm.calls[1]["user"]
    assert "tool error" in llm.calls[2]["user"]


def test_write_tools_are_blocked_by_default():
    llm = MockLLM([call("wipe"), FINAL])
    res = run_tool_loop(llm, "sys", "t", registry())
    assert res.ok
    assert "not allowed" in llm.calls[1]["user"]
    assert "gone" not in llm.calls[1]["user"]


def test_write_tools_run_only_when_allowed():
    llm = MockLLM([call("wipe"), FINAL])
    run_tool_loop(llm, "sys", "t", registry(), allow_write=True)
    assert "gone" in llm.calls[1]["user"]


def test_step_limit_and_repeat_guard():
    llm = MockLLM(["not json"] * 3)
    res = run_tool_loop(llm, "sys", "t", registry(), max_steps=3)
    assert not res.ok and "no final answer" in res.errors[0]
    llm = MockLLM([call("add", a=1, b=1)] * 5)
    res = run_tool_loop(llm, "sys", "t", registry(), max_steps=6)
    assert not res.ok and "repeated" in res.errors[0]
