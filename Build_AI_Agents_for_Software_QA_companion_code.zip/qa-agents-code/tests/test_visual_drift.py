import json
from pathlib import Path

import pytest

PIL = pytest.importorskip("PIL")
from PIL import Image  # noqa: E402

from qa_agents import fakes  # noqa: E402
from qa_agents.agents import visual_drift as vd  # noqa: E402
from qa_agents.llm import FunctionLLM, MockLLM  # noqa: E402

G = Path(__file__).parent.parent / "golden" / "visual"


def img(path, size=(100, 80), boxes=()):
    im = Image.new("RGB", size, "white")
    for x, y, w, h in boxes:
        im.paste((0, 0, 0), (x, y, x + w, y + h))
    im.save(path)
    return str(path)


def test_identical_images_have_no_regions(tmp_path):
    a = img(tmp_path / "a.png", boxes=[(10, 10, 20, 20)])
    d = vd.diff_images(a, a)
    assert d["regions"] == [] and d["ratio"] == 0
    assert vd.gate(d)["pass"]


def test_two_separate_changes_make_two_regions(tmp_path):
    a = img(tmp_path / "a.png", (200, 100))
    b = img(tmp_path / "b.png", (200, 100),
            [(10, 10, 20, 20), (150, 60, 20, 20)])
    d = vd.diff_images(a, b)
    assert len(d["regions"]) == 2
    assert d["changed_pixels"] == 800
    assert [r["id"] for r in d["regions"]] == ["R1", "R2"]


def test_adjacent_cells_merge_into_one_region(tmp_path):
    a = img(tmp_path / "a.png", (100, 50))
    b = img(tmp_path / "b.png", (100, 50), [(10, 10, 60, 10)])
    assert len(vd.diff_images(a, b)["regions"]) == 1


def test_small_noise_below_threshold_is_ignored(tmp_path):
    a = img(tmp_path / "a.png")
    im = Image.new("RGB", (100, 80), (250, 250, 250))
    im.save(tmp_path / "b.png")
    assert vd.diff_images(a, str(tmp_path / "b.png"))["regions"] == []


def test_ignore_box_masks_dynamic_areas(tmp_path):
    a = img(tmp_path / "a.png")
    b = img(tmp_path / "b.png", boxes=[(10, 10, 20, 20)])
    d = vd.diff_images(a, b, ignore=[(0, 0, 50, 50)])
    assert d["regions"] == [] and d["changed_pixels"] == 0


def test_size_change_is_reported_and_fails_the_gate(tmp_path):
    a = img(tmp_path / "a.png", (100, 80))
    b = img(tmp_path / "b.png", (100, 90))
    d = vd.diff_images(a, b)
    assert d["size_changed"] and not vd.gate(d)["pass"]


def test_box_diff_with_tolerance_and_repeated_selectors():
    old = [{"selector": "label", "x": 0, "y": 0, "w": 10, "h": 10},
           {"selector": "label", "x": 0, "y": 50, "w": 10, "h": 10},
           {"selector": "#gone", "x": 0, "y": 0, "w": 5, "h": 5}]
    new = [{"selector": "label", "x": 1, "y": 1, "w": 10, "h": 10},
           {"selector": "label", "x": 0, "y": 80, "w": 10, "h": 10},
           {"selector": "#new", "x": 0, "y": 0, "w": 5, "h": 5}]
    ch = {(c["element"], c["change"]) for c in vd.diff_boxes(old, new)}
    assert ch == {("label[1]", "moved"), ("#gone[0]", "removed"),
                  ("#new[0]", "added")}


def load(name):
    return json.loads((G / name).read_text("utf-8"))


def run(llm, note=""):
    return vd.review(llm, str(G / "baseline.png"),
                     str(G / "current.png"),
                     load("baseline_boxes.json"),
                     load("current_boxes.json"), note)


def test_real_screenshots_two_regions_and_failed_gate():
    res = run(FunctionLLM(fakes.fake_visual))
    assert res.ok and not res.gate["pass"]
    assert len(res.regions) == 2
    assert {f["verdict"] for f in res.findings} == {"likely_regression"}


def test_note_changes_the_verdict_but_not_the_gate():
    res = run(FunctionLLM(fakes.fake_visual), "Form fields now stack")
    assert {f["verdict"] for f in res.findings} == {"likely_intentional"}
    assert not res.gate["pass"]


def test_model_must_answer_for_every_region_and_use_real_elements():
    bad = json.dumps({"findings": [{
        "region_id": "R1", "verdict": "unclear", "reason": "x",
        "element": "#made-up"}]})
    llm = MockLLM([bad] * 3)
    res = run(llm)
    assert not res.ok
    assert "missing finding for R2" in llm.calls[1]["user"]
    assert "not in the region" in llm.calls[1]["user"]


def test_no_model_call_when_images_match():
    llm = MockLLM([])
    res = vd.review(llm, str(G / "baseline.png"),
                    str(G / "baseline.png"), [], [])
    assert res.ok and res.gate["pass"] and llm.calls == []


def test_overlay_draws_frames_and_keeps_size(tmp_path):
    a = img(tmp_path / "a.png", (100, 80))
    b = img(tmp_path / "b.png", (100, 80), [(20, 20, 20, 20)])
    d = vd.diff_images(a, b)
    out = vd.overlay(b, d["regions"], str(tmp_path / "o.png"))
    im = Image.open(out)
    r = d["regions"][0]
    assert im.size == (100, 80)
    assert im.getpixel((r["x"], r["y"] + 10)) == (214, 40, 40)
